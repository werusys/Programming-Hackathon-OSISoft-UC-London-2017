/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AnalysisApi = (function () {
        function AnalysisApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AnalysisApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AnalysisApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AnalysisApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.update = function (webId, analysis, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (analysis === null || analysis === undefined) {
                throw new Error('Required parameter analysis was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = analysis;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analyses/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AnalysisApi;
    }());
    PIWebApiClient.AnalysisApi = AnalysisApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AnalysisCategoryApi = (function () {
        function AnalysisCategoryApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AnalysisCategoryApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AnalysisCategoryApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AnalysisCategoryApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.update = function (webId, category, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (category === null || category === undefined) {
                throw new Error('Required parameter category was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = category;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisCategoryApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysiscategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AnalysisCategoryApi;
    }());
    PIWebApiClient.AnalysisCategoryApi = AnalysisCategoryApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AnalysisRuleApi = (function () {
        function AnalysisRuleApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AnalysisRuleApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AnalysisRuleApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AnalysisRuleApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRuleApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRuleApi.prototype.update = function (webId, analysisRule, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (analysisRule === null || analysisRule === undefined) {
                throw new Error('Required parameter analysisRule was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = analysisRule;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRuleApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRuleApi.prototype.getAnalysisRules = function (webId, maxCount, nameFilter, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules/{webId}/analysisrules'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalysisRules.');
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRuleApi.prototype.createAnalysisRule = function (webId, analysisRule, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisrules/{webId}/analysisrules'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAnalysisRule.');
            }
            if (analysisRule === null || analysisRule === undefined) {
                throw new Error('Required parameter analysisRule was null or undefined when calling createAnalysisRule.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = analysisRule;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AnalysisRuleApi;
    }());
    PIWebApiClient.AnalysisRuleApi = AnalysisRuleApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AnalysisRulePlugInApi = (function () {
        function AnalysisRulePlugInApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AnalysisRulePlugInApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AnalysisRulePlugInApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AnalysisRulePlugInApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisruleplugins';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisRulePlugInApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysisruleplugins/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AnalysisRulePlugInApi;
    }());
    PIWebApiClient.AnalysisRulePlugInApi = AnalysisRulePlugInApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AnalysisTemplateApi = (function () {
        function AnalysisTemplateApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AnalysisTemplateApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AnalysisTemplateApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AnalysisTemplateApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.createFromAnalysis = function (analysisWebId, name, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (analysisWebId === null || analysisWebId === undefined) {
                throw new Error('Required parameter analysisWebId was null or undefined when calling createFromAnalysis.');
            }
            if ((analysisWebId !== undefined) && (analysisWebId !== null)) {
                queryParameters['analysisWebId'] = analysisWebId;
            }
            if ((name !== undefined) && (name !== null)) {
                queryParameters['name'] = name;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.update = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AnalysisTemplateApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/analysistemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AnalysisTemplateApi;
    }());
    PIWebApiClient.AnalysisTemplateApi = AnalysisTemplateApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AssetDatabaseApi = (function () {
        function AssetDatabaseApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AssetDatabaseApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AssetDatabaseApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AssetDatabaseApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.update = function (webId, database, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (database === null || database === undefined) {
                throw new Error('Required parameter database was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = database;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.findAnalyses = function (webId, field, maxCount, query, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/analyses'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling findAnalyses.');
            }
            if (field === null || field === undefined) {
                throw new Error('Required parameter field was null or undefined when calling findAnalyses.');
            }
            if ((field !== undefined) && (field !== null)) {
                queryParameters['field'] = field;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((query !== undefined) && (query !== null)) {
                queryParameters['query'] = query;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getAnalysisCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/analysiscategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalysisCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createAnalysisCategory = function (webId, analysisCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/analysiscategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAnalysisCategory.');
            }
            if (analysisCategory === null || analysisCategory === undefined) {
                throw new Error('Required parameter analysisCategory was null or undefined when calling createAnalysisCategory.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = analysisCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getAnalysisTemplates = function (webId, field, maxCount, query, selectedFields, sortField, sortOrder, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/analysistemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalysisTemplates.');
            }
            if (field === null || field === undefined) {
                throw new Error('Required parameter field was null or undefined when calling getAnalysisTemplates.');
            }
            if ((field !== undefined) && (field !== null)) {
                queryParameters['field'] = field;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((query !== undefined) && (query !== null)) {
                queryParameters['query'] = query;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createAnalysisTemplate = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/analysistemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAnalysisTemplate.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling createAnalysisTemplate.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getAttributeCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/attributecategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributeCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createAttributeCategory = function (webId, attributeCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/attributecategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttributeCategory.');
            }
            if (attributeCategory === null || attributeCategory === undefined) {
                throw new Error('Required parameter attributeCategory was null or undefined when calling createAttributeCategory.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = attributeCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.findElementAttributes = function (webId, attributeCategory, attributeDescriptionFilter, attributeNameFilter, attributeType, elementCategory, elementDescriptionFilter, elementNameFilter, elementTemplate, elementType, maxCount, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elementattributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling findElementAttributes.');
            }
            if ((attributeCategory !== undefined) && (attributeCategory !== null)) {
                queryParameters['attributeCategory'] = attributeCategory;
            }
            if ((attributeDescriptionFilter !== undefined) && (attributeDescriptionFilter !== null)) {
                queryParameters['attributeDescriptionFilter'] = attributeDescriptionFilter;
            }
            if ((attributeNameFilter !== undefined) && (attributeNameFilter !== null)) {
                queryParameters['attributeNameFilter'] = attributeNameFilter;
            }
            if ((attributeType !== undefined) && (attributeType !== null)) {
                queryParameters['attributeType'] = attributeType;
            }
            if ((elementCategory !== undefined) && (elementCategory !== null)) {
                queryParameters['elementCategory'] = elementCategory;
            }
            if ((elementDescriptionFilter !== undefined) && (elementDescriptionFilter !== null)) {
                queryParameters['elementDescriptionFilter'] = elementDescriptionFilter;
            }
            if ((elementNameFilter !== undefined) && (elementNameFilter !== null)) {
                queryParameters['elementNameFilter'] = elementNameFilter;
            }
            if ((elementTemplate !== undefined) && (elementTemplate !== null)) {
                queryParameters['elementTemplate'] = elementTemplate;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getElementCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elementcategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getElementCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createElementCategory = function (webId, elementCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elementcategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createElementCategory.');
            }
            if (elementCategory === null || elementCategory === undefined) {
                throw new Error('Required parameter elementCategory was null or undefined when calling createElementCategory.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = elementCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getElements = function (webId, categoryName, descriptionFilter, elementType, maxCount, nameFilter, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getElements.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((descriptionFilter !== undefined) && (descriptionFilter !== null)) {
                queryParameters['descriptionFilter'] = descriptionFilter;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createElement = function (webId, element, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createElement.');
            }
            if (element === null || element === undefined) {
                throw new Error('Required parameter element was null or undefined when calling createElement.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = element;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getElementTemplates = function (webId, field, maxCount, query, selectedFields, sortField, sortOrder, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elementtemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getElementTemplates.');
            }
            if (field === null || field === undefined) {
                throw new Error('Required parameter field was null or undefined when calling getElementTemplates.');
            }
            if ((field !== undefined) && (field !== null)) {
                queryParameters['field'] = field;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((query !== undefined) && (query !== null)) {
                queryParameters['query'] = query;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createElementTemplate = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/elementtemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createElementTemplate.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling createElementTemplate.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getEnumerationSets = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/enumerationsets'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEnumerationSets.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createEnumerationSet = function (webId, enumerationSet, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/enumerationsets'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createEnumerationSet.');
            }
            if (enumerationSet === null || enumerationSet === undefined) {
                throw new Error('Required parameter enumerationSet was null or undefined when calling createEnumerationSet.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = enumerationSet;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.findEventFrameAttributes = function (webId, attributeCategory, attributeDescriptionFilter, attributeNameFilter, attributeType, endTime, eventFrameCategory, eventFrameDescriptionFilter, eventFrameNameFilter, eventFrameTemplate, maxCount, referencedElementNameFilter, searchFullHierarchy, searchMode, selectedFields, sortField, sortOrder, startIndex, startTime, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/eventframeattributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling findEventFrameAttributes.');
            }
            if ((attributeCategory !== undefined) && (attributeCategory !== null)) {
                queryParameters['attributeCategory'] = attributeCategory;
            }
            if ((attributeDescriptionFilter !== undefined) && (attributeDescriptionFilter !== null)) {
                queryParameters['attributeDescriptionFilter'] = attributeDescriptionFilter;
            }
            if ((attributeNameFilter !== undefined) && (attributeNameFilter !== null)) {
                queryParameters['attributeNameFilter'] = attributeNameFilter;
            }
            if ((attributeType !== undefined) && (attributeType !== null)) {
                queryParameters['attributeType'] = attributeType;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((eventFrameCategory !== undefined) && (eventFrameCategory !== null)) {
                queryParameters['eventFrameCategory'] = eventFrameCategory;
            }
            if ((eventFrameDescriptionFilter !== undefined) && (eventFrameDescriptionFilter !== null)) {
                queryParameters['eventFrameDescriptionFilter'] = eventFrameDescriptionFilter;
            }
            if ((eventFrameNameFilter !== undefined) && (eventFrameNameFilter !== null)) {
                queryParameters['eventFrameNameFilter'] = eventFrameNameFilter;
            }
            if ((eventFrameTemplate !== undefined) && (eventFrameTemplate !== null)) {
                queryParameters['eventFrameTemplate'] = eventFrameTemplate;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((referencedElementNameFilter !== undefined) && (referencedElementNameFilter !== null)) {
                queryParameters['referencedElementNameFilter'] = referencedElementNameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getEventFrames = function (webId, canBeAcknowledged, categoryName, endTime, isAcknowledged, maxCount, nameFilter, referencedElementNameFilter, referencedElementTemplateName, searchFullHierarchy, searchMode, selectedFields, severity, sortField, sortOrder, startIndex, startTime, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/eventframes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEventFrames.');
            }
            if ((canBeAcknowledged !== undefined) && (canBeAcknowledged !== null)) {
                queryParameters['canBeAcknowledged'] = canBeAcknowledged;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((isAcknowledged !== undefined) && (isAcknowledged !== null)) {
                queryParameters['isAcknowledged'] = isAcknowledged;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((referencedElementNameFilter !== undefined) && (referencedElementNameFilter !== null)) {
                queryParameters['referencedElementNameFilter'] = referencedElementNameFilter;
            }
            if ((referencedElementTemplateName !== undefined) && (referencedElementTemplateName !== null)) {
                queryParameters['referencedElementTemplateName'] = referencedElementTemplateName;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((severity !== undefined) && (severity !== null)) {
                queryParameters['severity'] = severity;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createEventFrame = function (webId, eventFrame, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/eventframes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createEventFrame.');
            }
            if (eventFrame === null || eventFrame === undefined) {
                throw new Error('Required parameter eventFrame was null or undefined when calling createEventFrame.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = eventFrame;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.export = function (webId, endTime, exportMode, startTime, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/export'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling export.');
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((exportMode !== undefined) && (exportMode !== null)) {
                queryParameters['exportMode'] = exportMode;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.import = function (webId, importMode, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/import'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling importData.');
            }
            if ((importMode !== undefined) && (importMode !== null)) {
                queryParameters['importMode'] = importMode;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getReferencedElements = function (webId, categoryName, descriptionFilter, elementType, maxCount, nameFilter, selectedFields, sortField, sortOrder, startIndex, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getReferencedElements.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((descriptionFilter !== undefined) && (descriptionFilter !== null)) {
                queryParameters['descriptionFilter'] = descriptionFilter;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.addReferencedElement = function (webId, referencedElementWebId, referenceType, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling addReferencedElement.');
            }
            if (referencedElementWebId === null || referencedElementWebId === undefined) {
                throw new Error('Required parameter referencedElementWebId was null or undefined when calling addReferencedElement.');
            }
            if ((referencedElementWebId !== undefined) && (referencedElementWebId !== null)) {
                queryParameters['referencedElementWebId'] = referencedElementWebId;
            }
            if ((referenceType !== undefined) && (referenceType !== null)) {
                queryParameters['referenceType'] = referenceType;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.removeReferencedElement = function (webId, referencedElementWebId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling removeReferencedElement.');
            }
            if (referencedElementWebId === null || referencedElementWebId === undefined) {
                throw new Error('Required parameter referencedElementWebId was null or undefined when calling removeReferencedElement.');
            }
            if ((referencedElementWebId !== undefined) && (referencedElementWebId !== null)) {
                queryParameters['referencedElementWebId'] = referencedElementWebId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getSecurity = function (webId, securityItem, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (securityItem === null || securityItem === undefined) {
                throw new Error('Required parameter securityItem was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getSecurityEntries = function (webId, nameFilter, securityItem, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getSecurityEntryByName = function (name, webId, securityItem, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getTableCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/tablecategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getTableCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createTableCategory = function (webId, tableCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/tablecategories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createTableCategory.');
            }
            if (tableCategory === null || tableCategory === undefined) {
                throw new Error('Required parameter tableCategory was null or undefined when calling createTableCategory.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = tableCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.getTables = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/tables'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getTables.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetDatabaseApi.prototype.createTable = function (webId, table, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetdatabases/{webId}/tables'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createTable.');
            }
            if (table === null || table === undefined) {
                throw new Error('Required parameter table was null or undefined when calling createTable.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = table;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AssetDatabaseApi;
    }());
    PIWebApiClient.AssetDatabaseApi = AssetDatabaseApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AssetServerApi = (function () {
        function AssetServerApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AssetServerApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AssetServerApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AssetServerApi.prototype.list = function (selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getByName = function (name, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getByName.');
            }
            if ((name !== undefined) && (name !== null)) {
                queryParameters['name'] = name;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getAnalysisRulePlugIns = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/analysisruleplugins'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalysisRulePlugIns.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getDatabases = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/assetdatabases'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getDatabases.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.createAssetDatabase = function (webId, database, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/assetdatabases'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAssetDatabase.');
            }
            if (database === null || database === undefined) {
                throw new Error('Required parameter database was null or undefined when calling createAssetDatabase.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = database;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurity = function (webId, securityItem, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (securityItem === null || securityItem === undefined) {
                throw new Error('Required parameter securityItem was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurityEntries = function (webId, nameFilter, securityItem, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurityEntryByName = function (name, webId, securityItem, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, securityItem, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            if ((securityItem !== undefined) && (securityItem !== null)) {
                queryParameters['securityItem'] = securityItem;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurityIdentities = function (webId, field, maxCount, query, selectedFields, sortField, sortOrder, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityidentities'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityIdentities.');
            }
            if ((field !== undefined) && (field !== null)) {
                queryParameters['field'] = field;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((query !== undefined) && (query !== null)) {
                queryParameters['query'] = query;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.createSecurityIdentity = function (webId, securityIdentity, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityidentities'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityIdentity.');
            }
            if (securityIdentity === null || securityIdentity === undefined) {
                throw new Error('Required parameter securityIdentity was null or undefined when calling createSecurityIdentity.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityIdentity;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurityIdentitiesForUser = function (webId, userIdentity, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securityidentities'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityIdentitiesForUser.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurityIdentitiesForUser.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getSecurityMappings = function (webId, field, maxCount, query, selectedFields, sortField, sortOrder, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securitymappings'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityMappings.');
            }
            if ((field !== undefined) && (field !== null)) {
                queryParameters['field'] = field;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((query !== undefined) && (query !== null)) {
                queryParameters['query'] = query;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.createSecurityMapping = function (webId, securityMapping, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/securitymappings'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityMapping.');
            }
            if (securityMapping === null || securityMapping === undefined) {
                throw new Error('Required parameter securityMapping was null or undefined when calling createSecurityMapping.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityMapping;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getTimeRulePlugIns = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/timeruleplugins'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getTimeRulePlugIns.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.getUnitClasses = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/unitclasses'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getUnitClasses.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AssetServerApi.prototype.createUnitClass = function (webId, unitClass, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/assetservers/{webId}/unitclasses'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createUnitClass.');
            }
            if (unitClass === null || unitClass === undefined) {
                throw new Error('Required parameter unitClass was null or undefined when calling createUnitClass.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = unitClass;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AssetServerApi;
    }());
    PIWebApiClient.AssetServerApi = AssetServerApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AttributeApi = (function () {
        function AttributeApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AttributeApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AttributeApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AttributeApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.update = function (webId, attribute, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (attribute === null || attribute === undefined) {
                throw new Error('Required parameter attribute was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = attribute;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.getAttributes = function (webId, categoryName, maxCount, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, sortField, sortOrder, startIndex, templateName, valueType, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributes.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((valueType !== undefined) && (valueType !== null)) {
                queryParameters['valueType'] = valueType;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.createAttribute = function (webId, attribute, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttribute.');
            }
            if (attribute === null || attribute === undefined) {
                throw new Error('Required parameter attribute was null or undefined when calling createAttribute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = attribute;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.createConfig = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/config'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createConfig.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.getValue = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getValue.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.setValue = function (webId, value, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling setValue.');
            }
            if (value === null || value === undefined) {
                throw new Error('Required parameter value was null or undefined when calling setValue.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = value;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeApi.prototype.getMultiple = function (asParallel, includeMode, path, selectedFields, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributes/multiple';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((asParallel !== undefined) && (asParallel !== null)) {
                queryParameters['asParallel'] = asParallel;
            }
            if ((includeMode !== undefined) && (includeMode !== null)) {
                queryParameters['includeMode'] = includeMode;
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AttributeApi;
    }());
    PIWebApiClient.AttributeApi = AttributeApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AttributeCategoryApi = (function () {
        function AttributeCategoryApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AttributeCategoryApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AttributeCategoryApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AttributeCategoryApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.update = function (webId, category, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (category === null || category === undefined) {
                throw new Error('Required parameter category was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = category;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeCategoryApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AttributeCategoryApi;
    }());
    PIWebApiClient.AttributeCategoryApi = AttributeCategoryApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AttributeTemplateApi = (function () {
        function AttributeTemplateApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AttributeTemplateApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AttributeTemplateApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AttributeTemplateApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.update = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.getAttributeTemplates = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}/attributetemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributeTemplates.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.createAttributeTemplate = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}/attributetemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttributeTemplate.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling createAttributeTemplate.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTemplateApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetemplates/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AttributeTemplateApi;
    }());
    PIWebApiClient.AttributeTemplateApi = AttributeTemplateApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var AttributeTraitApi = (function () {
        function AttributeTraitApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        AttributeTraitApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        AttributeTraitApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        AttributeTraitApi.prototype.getByCategory = function (category, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetraits';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (category === null || category === undefined) {
                throw new Error('Required parameter category was null or undefined when calling getByCategory.');
            }
            if ((category !== undefined) && (category !== null)) {
                queryParameters['category'] = category;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        AttributeTraitApi.prototype.get = function (name, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/attributetraits/{name}'
                .replace('{' + 'name' + '}', String(name));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return AttributeTraitApi;
    }());
    PIWebApiClient.AttributeTraitApi = AttributeTraitApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var BatchApi = (function () {
        function BatchApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        BatchApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        BatchApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        BatchApi.prototype.execute = function (batch, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/batch';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (batch === null || batch === undefined) {
                throw new Error('Required parameter batch was null or undefined when calling execute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = batch;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return BatchApi;
    }());
    PIWebApiClient.BatchApi = BatchApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var CalculationApi = (function () {
        function CalculationApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        CalculationApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        CalculationApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        CalculationApi.prototype.getAtIntervals = function (endTime, expression, sampleInterval, selectedFields, startTime, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/calculation/intervals';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((expression !== undefined) && (expression !== null)) {
                queryParameters['expression'] = expression;
            }
            if ((sampleInterval !== undefined) && (sampleInterval !== null)) {
                queryParameters['sampleInterval'] = sampleInterval;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        CalculationApi.prototype.getAtRecorded = function (endTime, expression, selectedFields, startTime, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/calculation/recorded';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((expression !== undefined) && (expression !== null)) {
                queryParameters['expression'] = expression;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        CalculationApi.prototype.getSummary = function (calculationBasis, endTime, expression, sampleInterval, sampleType, selectedFields, startTime, summaryDuration, summaryType, timeType, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/calculation/summary';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((calculationBasis !== undefined) && (calculationBasis !== null)) {
                queryParameters['calculationBasis'] = calculationBasis;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((expression !== undefined) && (expression !== null)) {
                queryParameters['expression'] = expression;
            }
            if ((sampleInterval !== undefined) && (sampleInterval !== null)) {
                queryParameters['sampleInterval'] = sampleInterval;
            }
            if ((sampleType !== undefined) && (sampleType !== null)) {
                queryParameters['sampleType'] = sampleType;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((summaryDuration !== undefined) && (summaryDuration !== null)) {
                queryParameters['summaryDuration'] = summaryDuration;
            }
            if ((summaryType !== undefined) && (summaryType !== null)) {
                queryParameters['summaryType'] = summaryType;
            }
            if ((timeType !== undefined) && (timeType !== null)) {
                queryParameters['timeType'] = timeType;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        CalculationApi.prototype.getAtTimes = function (expression, selectedFields, sortOrder, time, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/calculation/times';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((expression !== undefined) && (expression !== null)) {
                queryParameters['expression'] = expression;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return CalculationApi;
    }());
    PIWebApiClient.CalculationApi = CalculationApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var ChannelApi = (function () {
        function ChannelApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        ChannelApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        ChannelApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        ChannelApi.prototype.instances = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/channels/instances';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return ChannelApi;
    }());
    PIWebApiClient.ChannelApi = ChannelApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var ConfigurationApi = (function () {
        function ConfigurationApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        ConfigurationApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        ConfigurationApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        ConfigurationApi.prototype.list = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/configuration';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ConfigurationApi.prototype.get = function (key, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/configuration/{key}'
                .replace('{' + 'key' + '}', String(key));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (key === null || key === undefined) {
                throw new Error('Required parameter key was null or undefined when calling get.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ConfigurationApi.prototype.delete = function (key, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/configuration/{key}'
                .replace('{' + 'key' + '}', String(key));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (key === null || key === undefined) {
                throw new Error('Required parameter key was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ConfigurationApi.prototype.put = function (key, value, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/configuration/{key}'
                .replace('{' + 'key' + '}', String(key));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (key === null || key === undefined) {
                throw new Error('Required parameter key was null or undefined when calling put.');
            }
            if (value === null || value === undefined) {
                throw new Error('Required parameter value was null or undefined when calling put.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = value;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return ConfigurationApi;
    }());
    PIWebApiClient.ConfigurationApi = ConfigurationApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var DataServerApi = (function () {
        function DataServerApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        DataServerApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        DataServerApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        DataServerApi.prototype.list = function (selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.getByName = function (name, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getByName.');
            }
            if ((name !== undefined) && (name !== null)) {
                queryParameters['name'] = name;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.getEnumerationSets = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers/{webId}/enumerationsets'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEnumerationSets.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.createEnumerationSet = function (webId, enumerationSet, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers/{webId}/enumerationsets'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createEnumerationSet.');
            }
            if (enumerationSet === null || enumerationSet === undefined) {
                throw new Error('Required parameter enumerationSet was null or undefined when calling createEnumerationSet.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = enumerationSet;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.getPoints = function (webId, maxCount, nameFilter, selectedFields, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers/{webId}/points'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getPoints.');
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        DataServerApi.prototype.createPoint = function (webId, pointDTO, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/dataservers/{webId}/points'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createPoint.');
            }
            if (pointDTO === null || pointDTO === undefined) {
                throw new Error('Required parameter pointDTO was null or undefined when calling createPoint.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = pointDTO;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return DataServerApi;
    }());
    PIWebApiClient.DataServerApi = DataServerApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var ElementApi = (function () {
        function ElementApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        ElementApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        ElementApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        ElementApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.update = function (webId, element, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (element === null || element === undefined) {
                throw new Error('Required parameter element was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = element;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getAnalyses = function (webId, maxCount, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/analyses'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalyses.');
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createAnalysis = function (webId, analysis, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/analyses'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAnalysis.');
            }
            if (analysis === null || analysis === undefined) {
                throw new Error('Required parameter analysis was null or undefined when calling createAnalysis.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = analysis;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getAttributes = function (webId, categoryName, maxCount, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, sortField, sortOrder, startIndex, templateName, valueType, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributes.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((valueType !== undefined) && (valueType !== null)) {
                queryParameters['valueType'] = valueType;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createAttribute = function (webId, attribute, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttribute.');
            }
            if (attribute === null || attribute === undefined) {
                throw new Error('Required parameter attribute was null or undefined when calling createAttribute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = attribute;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createConfig = function (webId, includeChildElements, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/config'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createConfig.');
            }
            if ((includeChildElements !== undefined) && (includeChildElements !== null)) {
                queryParameters['includeChildElements'] = includeChildElements;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.findElementAttributes = function (webId, attributeCategory, attributeDescriptionFilter, attributeNameFilter, attributeType, elementCategory, elementDescriptionFilter, elementNameFilter, elementTemplate, elementType, maxCount, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/elementattributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling findElementAttributes.');
            }
            if ((attributeCategory !== undefined) && (attributeCategory !== null)) {
                queryParameters['attributeCategory'] = attributeCategory;
            }
            if ((attributeDescriptionFilter !== undefined) && (attributeDescriptionFilter !== null)) {
                queryParameters['attributeDescriptionFilter'] = attributeDescriptionFilter;
            }
            if ((attributeNameFilter !== undefined) && (attributeNameFilter !== null)) {
                queryParameters['attributeNameFilter'] = attributeNameFilter;
            }
            if ((attributeType !== undefined) && (attributeType !== null)) {
                queryParameters['attributeType'] = attributeType;
            }
            if ((elementCategory !== undefined) && (elementCategory !== null)) {
                queryParameters['elementCategory'] = elementCategory;
            }
            if ((elementDescriptionFilter !== undefined) && (elementDescriptionFilter !== null)) {
                queryParameters['elementDescriptionFilter'] = elementDescriptionFilter;
            }
            if ((elementNameFilter !== undefined) && (elementNameFilter !== null)) {
                queryParameters['elementNameFilter'] = elementNameFilter;
            }
            if ((elementTemplate !== undefined) && (elementTemplate !== null)) {
                queryParameters['elementTemplate'] = elementTemplate;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getElements = function (webId, categoryName, descriptionFilter, elementType, maxCount, nameFilter, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/elements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getElements.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((descriptionFilter !== undefined) && (descriptionFilter !== null)) {
                queryParameters['descriptionFilter'] = descriptionFilter;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createElement = function (webId, element, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/elements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createElement.');
            }
            if (element === null || element === undefined) {
                throw new Error('Required parameter element was null or undefined when calling createElement.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = element;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getEventFrames = function (webId, canBeAcknowledged, categoryName, endTime, isAcknowledged, maxCount, nameFilter, searchMode, selectedFields, severity, sortField, sortOrder, startIndex, startTime, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/eventframes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEventFrames.');
            }
            if ((canBeAcknowledged !== undefined) && (canBeAcknowledged !== null)) {
                queryParameters['canBeAcknowledged'] = canBeAcknowledged;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((isAcknowledged !== undefined) && (isAcknowledged !== null)) {
                queryParameters['isAcknowledged'] = isAcknowledged;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((severity !== undefined) && (severity !== null)) {
                queryParameters['severity'] = severity;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getReferencedElements = function (webId, categoryName, descriptionFilter, elementType, maxCount, nameFilter, selectedFields, sortField, sortOrder, startIndex, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getReferencedElements.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((descriptionFilter !== undefined) && (descriptionFilter !== null)) {
                queryParameters['descriptionFilter'] = descriptionFilter;
            }
            if ((elementType !== undefined) && (elementType !== null)) {
                queryParameters['elementType'] = elementType;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.addReferencedElement = function (webId, referencedElementWebId, referenceType, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling addReferencedElement.');
            }
            if (referencedElementWebId === null || referencedElementWebId === undefined) {
                throw new Error('Required parameter referencedElementWebId was null or undefined when calling addReferencedElement.');
            }
            if ((referencedElementWebId !== undefined) && (referencedElementWebId !== null)) {
                queryParameters['referencedElementWebId'] = referencedElementWebId;
            }
            if ((referenceType !== undefined) && (referenceType !== null)) {
                queryParameters['referenceType'] = referenceType;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.removeReferencedElement = function (webId, referencedElementWebId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling removeReferencedElement.');
            }
            if (referencedElementWebId === null || referencedElementWebId === undefined) {
                throw new Error('Required parameter referencedElementWebId was null or undefined when calling removeReferencedElement.');
            }
            if ((referencedElementWebId !== undefined) && (referencedElementWebId !== null)) {
                queryParameters['referencedElementWebId'] = referencedElementWebId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.getMultiple = function (asParallel, includeMode, path, selectedFields, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/multiple';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((asParallel !== undefined) && (asParallel !== null)) {
                queryParameters['asParallel'] = asParallel;
            }
            if ((includeMode !== undefined) && (includeMode !== null)) {
                queryParameters['includeMode'] = includeMode;
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.createSearchByAttribute = function (search, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/searchbyattribute';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (search === null || search === undefined) {
                throw new Error('Required parameter search was null or undefined when calling createSearchByAttribute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = search;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementApi.prototype.executeSearchByAttribute = function (searchId, categoryName, descriptionFilter, maxCount, nameFilter, searchFullHierarchy, selectedFields, sortField, sortOrder, startIndex, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elements/searchbyattribute/{searchId}'
                .replace('{' + 'searchId' + '}', String(searchId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (searchId === null || searchId === undefined) {
                throw new Error('Required parameter searchId was null or undefined when calling executeSearchByAttribute.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((descriptionFilter !== undefined) && (descriptionFilter !== null)) {
                queryParameters['descriptionFilter'] = descriptionFilter;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return ElementApi;
    }());
    PIWebApiClient.ElementApi = ElementApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var ElementCategoryApi = (function () {
        function ElementCategoryApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        ElementCategoryApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        ElementCategoryApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        ElementCategoryApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.update = function (webId, elementCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (elementCategory === null || elementCategory === undefined) {
                throw new Error('Required parameter elementCategory was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = elementCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementCategoryApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementcategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return ElementCategoryApi;
    }());
    PIWebApiClient.ElementCategoryApi = ElementCategoryApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var ElementTemplateApi = (function () {
        function ElementTemplateApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        ElementTemplateApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        ElementTemplateApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        ElementTemplateApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.update = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getAnalysisTemplates = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/analysistemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnalysisTemplates.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getAttributeTemplates = function (webId, selectedFields, showInherited, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/attributetemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributeTemplates.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showInherited !== undefined) && (showInherited !== null)) {
                queryParameters['showInherited'] = showInherited;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.createAttributeTemplate = function (webId, template, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/attributetemplates'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttributeTemplate.');
            }
            if (template === null || template === undefined) {
                throw new Error('Required parameter template was null or undefined when calling createAttributeTemplate.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = template;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getCategories = function (webId, selectedFields, showInherited, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showInherited !== undefined) && (showInherited !== null)) {
                queryParameters['showInherited'] = showInherited;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        ElementTemplateApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/elementtemplates/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return ElementTemplateApi;
    }());
    PIWebApiClient.ElementTemplateApi = ElementTemplateApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var EnumerationSetApi = (function () {
        function EnumerationSetApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        EnumerationSetApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        EnumerationSetApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        EnumerationSetApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.update = function (webId, enumerationSet, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (enumerationSet === null || enumerationSet === undefined) {
                throw new Error('Required parameter enumerationSet was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = enumerationSet;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.getValues = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/enumerationvalues'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getValues.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.createValue = function (webId, enumerationValue, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/enumerationvalues'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createValue.');
            }
            if (enumerationValue === null || enumerationValue === undefined) {
                throw new Error('Required parameter enumerationValue was null or undefined when calling createValue.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = enumerationValue;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationSetApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationsets/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return EnumerationSetApi;
    }());
    PIWebApiClient.EnumerationSetApi = EnumerationSetApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var EnumerationValueApi = (function () {
        function EnumerationValueApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        EnumerationValueApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        EnumerationValueApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        EnumerationValueApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationvalues';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationValueApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationvalues/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationValueApi.prototype.updateEnumerationValue = function (webId, enumerationValue, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationvalues/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateEnumerationValue.');
            }
            if (enumerationValue === null || enumerationValue === undefined) {
                throw new Error('Required parameter enumerationValue was null or undefined when calling updateEnumerationValue.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = enumerationValue;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EnumerationValueApi.prototype.deleteEnumerationValue = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/enumerationvalues/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteEnumerationValue.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return EnumerationValueApi;
    }());
    PIWebApiClient.EnumerationValueApi = EnumerationValueApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var EventFrameApi = (function () {
        function EventFrameApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        EventFrameApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        EventFrameApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        EventFrameApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.update = function (webId, eventFrame, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (eventFrame === null || eventFrame === undefined) {
                throw new Error('Required parameter eventFrame was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = eventFrame;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.acknowledge = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/acknowledge'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling acknowledge.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getAnnotations = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/annotations'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnnotations.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createAnnotation = function (webId, annotation, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/annotations'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAnnotation.');
            }
            if (annotation === null || annotation === undefined) {
                throw new Error('Required parameter annotation was null or undefined when calling createAnnotation.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = annotation;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getAnnotationById = function (id, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/annotations/{id}'
                .replace('{' + 'id' + '}', String(id))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (id === null || id === undefined) {
                throw new Error('Required parameter id was null or undefined when calling getAnnotationById.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAnnotationById.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.updateAnnotation = function (id, webId, annotation, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/annotations/{id}'
                .replace('{' + 'id' + '}', String(id))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (id === null || id === undefined) {
                throw new Error('Required parameter id was null or undefined when calling updateAnnotation.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateAnnotation.');
            }
            if (annotation === null || annotation === undefined) {
                throw new Error('Required parameter annotation was null or undefined when calling updateAnnotation.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = annotation;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.deleteAnnotation = function (id, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/annotations/{id}'
                .replace('{' + 'id' + '}', String(id))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (id === null || id === undefined) {
                throw new Error('Required parameter id was null or undefined when calling deleteAnnotation.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteAnnotation.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getAttributes = function (webId, categoryName, maxCount, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, sortField, sortOrder, startIndex, templateName, valueType, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributes.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((valueType !== undefined) && (valueType !== null)) {
                queryParameters['valueType'] = valueType;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createAttribute = function (webId, attribute, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createAttribute.');
            }
            if (attribute === null || attribute === undefined) {
                throw new Error('Required parameter attribute was null or undefined when calling createAttribute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = attribute;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.captureValues = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/attributes/capture'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling captureValues.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createConfig = function (webId, includeChildElements, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/config'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createConfig.');
            }
            if ((includeChildElements !== undefined) && (includeChildElements !== null)) {
                queryParameters['includeChildElements'] = includeChildElements;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.findEventFrameAttributes = function (webId, attributeCategory, attributeDescriptionFilter, attributeNameFilter, attributeType, endTime, eventFrameCategory, eventFrameDescriptionFilter, eventFrameNameFilter, eventFrameTemplate, maxCount, referencedElementNameFilter, searchFullHierarchy, searchMode, selectedFields, sortField, sortOrder, startIndex, startTime, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/eventframeattributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling findEventFrameAttributes.');
            }
            if ((attributeCategory !== undefined) && (attributeCategory !== null)) {
                queryParameters['attributeCategory'] = attributeCategory;
            }
            if ((attributeDescriptionFilter !== undefined) && (attributeDescriptionFilter !== null)) {
                queryParameters['attributeDescriptionFilter'] = attributeDescriptionFilter;
            }
            if ((attributeNameFilter !== undefined) && (attributeNameFilter !== null)) {
                queryParameters['attributeNameFilter'] = attributeNameFilter;
            }
            if ((attributeType !== undefined) && (attributeType !== null)) {
                queryParameters['attributeType'] = attributeType;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((eventFrameCategory !== undefined) && (eventFrameCategory !== null)) {
                queryParameters['eventFrameCategory'] = eventFrameCategory;
            }
            if ((eventFrameDescriptionFilter !== undefined) && (eventFrameDescriptionFilter !== null)) {
                queryParameters['eventFrameDescriptionFilter'] = eventFrameDescriptionFilter;
            }
            if ((eventFrameNameFilter !== undefined) && (eventFrameNameFilter !== null)) {
                queryParameters['eventFrameNameFilter'] = eventFrameNameFilter;
            }
            if ((eventFrameTemplate !== undefined) && (eventFrameTemplate !== null)) {
                queryParameters['eventFrameTemplate'] = eventFrameTemplate;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((referencedElementNameFilter !== undefined) && (referencedElementNameFilter !== null)) {
                queryParameters['referencedElementNameFilter'] = referencedElementNameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getEventFrames = function (webId, canBeAcknowledged, categoryName, endTime, isAcknowledged, maxCount, nameFilter, referencedElementNameFilter, referencedElementTemplateName, searchFullHierarchy, searchMode, selectedFields, severity, sortField, sortOrder, startIndex, startTime, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/eventframes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEventFrames.');
            }
            if ((canBeAcknowledged !== undefined) && (canBeAcknowledged !== null)) {
                queryParameters['canBeAcknowledged'] = canBeAcknowledged;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((isAcknowledged !== undefined) && (isAcknowledged !== null)) {
                queryParameters['isAcknowledged'] = isAcknowledged;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((referencedElementNameFilter !== undefined) && (referencedElementNameFilter !== null)) {
                queryParameters['referencedElementNameFilter'] = referencedElementNameFilter;
            }
            if ((referencedElementTemplateName !== undefined) && (referencedElementTemplateName !== null)) {
                queryParameters['referencedElementTemplateName'] = referencedElementTemplateName;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((severity !== undefined) && (severity !== null)) {
                queryParameters['severity'] = severity;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createEventFrame = function (webId, eventFrame, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/eventframes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createEventFrame.');
            }
            if (eventFrame === null || eventFrame === undefined) {
                throw new Error('Required parameter eventFrame was null or undefined when calling createEventFrame.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = eventFrame;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getReferencedElements = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/referencedelements'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getReferencedElements.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.getMultiple = function (asParallel, includeMode, path, selectedFields, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/multiple';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((asParallel !== undefined) && (asParallel !== null)) {
                queryParameters['asParallel'] = asParallel;
            }
            if ((includeMode !== undefined) && (includeMode !== null)) {
                queryParameters['includeMode'] = includeMode;
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.createSearchByAttribute = function (search, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/searchbyattribute';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (search === null || search === undefined) {
                throw new Error('Required parameter search was null or undefined when calling createSearchByAttribute.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = search;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        EventFrameApi.prototype.executeSearchByAttribute = function (searchId, canBeAcknowledged, endTime, isAcknowledged, maxCount, nameFilter, referencedElementNameFilter, searchFullHierarchy, searchMode, selectedFields, severity, sortField, sortOrder, startIndex, startTime, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/eventframes/searchbyattribute/{searchId}'
                .replace('{' + 'searchId' + '}', String(searchId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (searchId === null || searchId === undefined) {
                throw new Error('Required parameter searchId was null or undefined when calling executeSearchByAttribute.');
            }
            if ((canBeAcknowledged !== undefined) && (canBeAcknowledged !== null)) {
                queryParameters['canBeAcknowledged'] = canBeAcknowledged;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((isAcknowledged !== undefined) && (isAcknowledged !== null)) {
                queryParameters['isAcknowledged'] = isAcknowledged;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((referencedElementNameFilter !== undefined) && (referencedElementNameFilter !== null)) {
                queryParameters['referencedElementNameFilter'] = referencedElementNameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((searchMode !== undefined) && (searchMode !== null)) {
                queryParameters['searchMode'] = searchMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((severity !== undefined) && (severity !== null)) {
                queryParameters['severity'] = severity;
            }
            if ((sortField !== undefined) && (sortField !== null)) {
                queryParameters['sortField'] = sortField;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((startIndex !== undefined) && (startIndex !== null)) {
                queryParameters['startIndex'] = startIndex;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return EventFrameApi;
    }());
    PIWebApiClient.EventFrameApi = EventFrameApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var HomeApi = (function () {
        function HomeApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        HomeApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        HomeApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        HomeApi.prototype.get = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return HomeApi;
    }());
    PIWebApiClient.HomeApi = HomeApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PointApi = (function () {
        function PointApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        PointApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        PointApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        PointApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.update = function (webId, pointDTO, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (pointDTO === null || pointDTO === undefined) {
                throw new Error('Required parameter pointDTO was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = pointDTO;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.getAttributes = function (webId, name, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}/attributes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributes.');
            }
            if ((name !== undefined) && (name !== null)) {
                queryParameters['name'] = name;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.getAttributeByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}/attributes/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getAttributeByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getAttributeByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.updateAttributeValue = function (webId, name, value, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/{webId}/attributes/{name}'
                .replace('{' + 'webId' + '}', String(webId))
                .replace('{' + 'name' + '}', String(name));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateAttributeValue.');
            }
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateAttributeValue.');
            }
            if (value === null || value === undefined) {
                throw new Error('Required parameter value was null or undefined when calling updateAttributeValue.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = value;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        PointApi.prototype.getMultiple = function (asParallel, includeMode, path, selectedFields, webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/points/multiple';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if ((asParallel !== undefined) && (asParallel !== null)) {
                queryParameters['asParallel'] = asParallel;
            }
            if ((includeMode !== undefined) && (includeMode !== null)) {
                queryParameters['includeMode'] = includeMode;
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return PointApi;
    }());
    PIWebApiClient.PointApi = PointApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var SecurityIdentityApi = (function () {
        function SecurityIdentityApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        SecurityIdentityApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        SecurityIdentityApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        SecurityIdentityApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.update = function (webId, securityIdentity, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (securityIdentity === null || securityIdentity === undefined) {
                throw new Error('Required parameter securityIdentity was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityIdentity;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityIdentityApi.prototype.getSecurityMappings = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securityidentities/{webId}/securitymappings'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityMappings.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return SecurityIdentityApi;
    }());
    PIWebApiClient.SecurityIdentityApi = SecurityIdentityApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var SecurityMappingApi = (function () {
        function SecurityMappingApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        SecurityMappingApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        SecurityMappingApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        SecurityMappingApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.update = function (webId, securityMapping, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (securityMapping === null || securityMapping === undefined) {
                throw new Error('Required parameter securityMapping was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityMapping;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SecurityMappingApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/securitymappings/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return SecurityMappingApi;
    }());
    PIWebApiClient.SecurityMappingApi = SecurityMappingApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var StreamApi = (function () {
        function StreamApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        StreamApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        StreamApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        StreamApi.prototype.getChannel = function (webId, includeInitialValues, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/channel'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getChannel.');
            }
            if ((includeInitialValues !== undefined) && (includeInitialValues !== null)) {
                queryParameters['includeInitialValues'] = includeInitialValues;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getEnd = function (webId, desiredUnits, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/end'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEnd.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getInterpolated = function (webId, desiredUnits, endTime, filterExpression, includeFilteredValues, interval, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/interpolated'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolated.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((interval !== undefined) && (interval !== null)) {
                queryParameters['interval'] = interval;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getInterpolatedAtTimes = function (webId, desiredUnits, filterExpression, includeFilteredValues, selectedFields, sortOrder, time, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/interpolatedattimes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolatedAtTimes.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getPlot = function (webId, desiredUnits, endTime, intervals, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/plot'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getPlot.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((intervals !== undefined) && (intervals !== null)) {
                queryParameters['intervals'] = intervals;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getRecorded = function (webId, boundaryType, desiredUnits, endTime, filterExpression, includeFilteredValues, maxCount, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/recorded'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecorded.');
            }
            if ((boundaryType !== undefined) && (boundaryType !== null)) {
                queryParameters['boundaryType'] = boundaryType;
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.updateValues = function (webId, values, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/recorded'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateValues.');
            }
            if (values === null || values === undefined) {
                throw new Error('Required parameter values was null or undefined when calling updateValues.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = values;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getRecordedAtTime = function (webId, time, desiredUnits, retrievalMode, selectedFields, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/recordedattime'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTime.');
            }
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getRecordedAtTime.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getRecordedAtTimes = function (webId, desiredUnits, retrievalMode, selectedFields, sortOrder, time, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/recordedattimes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTimes.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getSummary = function (webId, calculationBasis, endTime, filterExpression, sampleInterval, sampleType, selectedFields, startTime, summaryDuration, summaryType, timeType, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/summary'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSummary.');
            }
            if ((calculationBasis !== undefined) && (calculationBasis !== null)) {
                queryParameters['calculationBasis'] = calculationBasis;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((sampleInterval !== undefined) && (sampleInterval !== null)) {
                queryParameters['sampleInterval'] = sampleInterval;
            }
            if ((sampleType !== undefined) && (sampleType !== null)) {
                queryParameters['sampleType'] = sampleType;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((summaryDuration !== undefined) && (summaryDuration !== null)) {
                queryParameters['summaryDuration'] = summaryDuration;
            }
            if ((summaryType !== undefined) && (summaryType !== null)) {
                queryParameters['summaryType'] = summaryType;
            }
            if ((timeType !== undefined) && (timeType !== null)) {
                queryParameters['timeType'] = timeType;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.getValue = function (webId, desiredUnits, selectedFields, time, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getValue.');
            }
            if ((desiredUnits !== undefined) && (desiredUnits !== null)) {
                queryParameters['desiredUnits'] = desiredUnits;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamApi.prototype.updateValue = function (webId, value, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streams/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateValue.');
            }
            if (value === null || value === undefined) {
                throw new Error('Required parameter value was null or undefined when calling updateValue.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = value;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return StreamApi;
    }());
    PIWebApiClient.StreamApi = StreamApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var StreamSetApi = (function () {
        function StreamSetApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        StreamSetApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        StreamSetApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        StreamSetApi.prototype.getChannel = function (webId, categoryName, includeInitialValues, nameFilter, searchFullHierarchy, showExcluded, showHidden, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/channel'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getChannel.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((includeInitialValues !== undefined) && (includeInitialValues !== null)) {
                queryParameters['includeInitialValues'] = includeInitialValues;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getEnd = function (webId, categoryName, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, templateName, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/end'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEnd.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getInterpolated = function (webId, categoryName, endTime, filterExpression, includeFilteredValues, interval, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, startTime, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/interpolated'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolated.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((interval !== undefined) && (interval !== null)) {
                queryParameters['interval'] = interval;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getInterpolatedAtTimes = function (webId, time, categoryName, filterExpression, includeFilteredValues, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, sortOrder, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/interpolatedattimes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolatedAtTimes.');
            }
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getInterpolatedAtTimes.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getPlot = function (webId, categoryName, endTime, intervals, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, startTime, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/plot'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getPlot.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((intervals !== undefined) && (intervals !== null)) {
                queryParameters['intervals'] = intervals;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecorded = function (webId, boundaryType, categoryName, endTime, filterExpression, includeFilteredValues, maxCount, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, startTime, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/recorded'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecorded.');
            }
            if ((boundaryType !== undefined) && (boundaryType !== null)) {
                queryParameters['boundaryType'] = boundaryType;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.updateValues = function (webId, values, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/recorded'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateValues.');
            }
            if (values === null || values === undefined) {
                throw new Error('Required parameter values was null or undefined when calling updateValues.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = values;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecordedAtTime = function (webId, time, categoryName, nameFilter, retrievalMode, searchFullHierarchy, selectedFields, showExcluded, showHidden, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/recordedattime'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTime.');
            }
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getRecordedAtTime.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecordedAtTimes = function (webId, time, categoryName, nameFilter, retrievalMode, searchFullHierarchy, selectedFields, showExcluded, showHidden, sortOrder, templateName, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/recordedattimes'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTimes.');
            }
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getRecordedAtTimes.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getSummaries = function (webId, calculationBasis, categoryName, endTime, filterExpression, nameFilter, sampleInterval, sampleType, searchFullHierarchy, selectedFields, showExcluded, showHidden, startTime, summaryDuration, summaryType, templateName, timeType, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/summary'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSummaries.');
            }
            if ((calculationBasis !== undefined) && (calculationBasis !== null)) {
                queryParameters['calculationBasis'] = calculationBasis;
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((sampleInterval !== undefined) && (sampleInterval !== null)) {
                queryParameters['sampleInterval'] = sampleInterval;
            }
            if ((sampleType !== undefined) && (sampleType !== null)) {
                queryParameters['sampleType'] = sampleType;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((summaryDuration !== undefined) && (summaryDuration !== null)) {
                queryParameters['summaryDuration'] = summaryDuration;
            }
            if ((summaryType !== undefined) && (summaryType !== null)) {
                queryParameters['summaryType'] = summaryType;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((timeType !== undefined) && (timeType !== null)) {
                queryParameters['timeType'] = timeType;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getValues = function (webId, categoryName, nameFilter, searchFullHierarchy, selectedFields, showExcluded, showHidden, templateName, time, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getValues.');
            }
            if ((categoryName !== undefined) && (categoryName !== null)) {
                queryParameters['categoryName'] = categoryName;
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((searchFullHierarchy !== undefined) && (searchFullHierarchy !== null)) {
                queryParameters['searchFullHierarchy'] = searchFullHierarchy;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((showExcluded !== undefined) && (showExcluded !== null)) {
                queryParameters['showExcluded'] = showExcluded;
            }
            if ((showHidden !== undefined) && (showHidden !== null)) {
                queryParameters['showHidden'] = showHidden;
            }
            if ((templateName !== undefined) && (templateName !== null)) {
                queryParameters['templateName'] = templateName;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.updateValue = function (webId, values, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/{webId}/value'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateValue.');
            }
            if (values === null || values === undefined) {
                throw new Error('Required parameter values was null or undefined when calling updateValue.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = values;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getChannelAdHoc = function (webId, includeInitialValues, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/channel';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getChannelAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((includeInitialValues !== undefined) && (includeInitialValues !== null)) {
                queryParameters['includeInitialValues'] = includeInitialValues;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getEndAdHoc = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/end';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getEndAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getInterpolatedAdHoc = function (webId, endTime, filterExpression, includeFilteredValues, interval, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/interpolated';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolatedAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((interval !== undefined) && (interval !== null)) {
                queryParameters['interval'] = interval;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getInterpolatedAtTimesAdHoc = function (time, webId, filterExpression, includeFilteredValues, selectedFields, sortOrder, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/interpolatedattimes';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getInterpolatedAtTimesAdHoc.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getInterpolatedAtTimesAdHoc.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getPlotAdHoc = function (webId, endTime, intervals, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/plot';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getPlotAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((intervals !== undefined) && (intervals !== null)) {
                queryParameters['intervals'] = intervals;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecordedAdHoc = function (webId, boundaryType, endTime, filterExpression, includeFilteredValues, maxCount, selectedFields, startTime, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/recorded';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((boundaryType !== undefined) && (boundaryType !== null)) {
                queryParameters['boundaryType'] = boundaryType;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((includeFilteredValues !== undefined) && (includeFilteredValues !== null)) {
                queryParameters['includeFilteredValues'] = includeFilteredValues;
            }
            if ((maxCount !== undefined) && (maxCount !== null)) {
                queryParameters['maxCount'] = maxCount;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.updateValuesAdHoc = function (values, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/recorded';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (values === null || values === undefined) {
                throw new Error('Required parameter values was null or undefined when calling updateValuesAdHoc.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = values;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecordedAtTimeAdHoc = function (time, webId, retrievalMode, selectedFields, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/recordedattime';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getRecordedAtTimeAdHoc.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTimeAdHoc.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getRecordedAtTimesAdHoc = function (time, webId, retrievalMode, selectedFields, sortOrder, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/recordedattimes';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (time === null || time === undefined) {
                throw new Error('Required parameter time was null or undefined when calling getRecordedAtTimesAdHoc.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getRecordedAtTimesAdHoc.');
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((retrievalMode !== undefined) && (retrievalMode !== null)) {
                queryParameters['retrievalMode'] = retrievalMode;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((sortOrder !== undefined) && (sortOrder !== null)) {
                queryParameters['sortOrder'] = sortOrder;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getSummariesAdHoc = function (webId, calculationBasis, endTime, filterExpression, sampleInterval, sampleType, selectedFields, startTime, summaryDuration, summaryType, timeType, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/summary';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSummariesAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((calculationBasis !== undefined) && (calculationBasis !== null)) {
                queryParameters['calculationBasis'] = calculationBasis;
            }
            if ((endTime !== undefined) && (endTime !== null)) {
                queryParameters['endTime'] = endTime;
            }
            if ((filterExpression !== undefined) && (filterExpression !== null)) {
                queryParameters['filterExpression'] = filterExpression;
            }
            if ((sampleInterval !== undefined) && (sampleInterval !== null)) {
                queryParameters['sampleInterval'] = sampleInterval;
            }
            if ((sampleType !== undefined) && (sampleType !== null)) {
                queryParameters['sampleType'] = sampleType;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((startTime !== undefined) && (startTime !== null)) {
                queryParameters['startTime'] = startTime;
            }
            if ((summaryDuration !== undefined) && (summaryDuration !== null)) {
                queryParameters['summaryDuration'] = summaryDuration;
            }
            if ((summaryType !== undefined) && (summaryType !== null)) {
                queryParameters['summaryType'] = summaryType;
            }
            if ((timeType !== undefined) && (timeType !== null)) {
                queryParameters['timeType'] = timeType;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.getValuesAdHoc = function (webId, selectedFields, time, timeZone, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/value';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getValuesAdHoc.');
            }
            if ((webId !== undefined) && (webId !== null)) {
                queryParameters['webId'] = webId;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            if ((time !== undefined) && (time !== null)) {
                queryParameters['time'] = time;
            }
            if ((timeZone !== undefined) && (timeZone !== null)) {
                queryParameters['timeZone'] = timeZone;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        StreamSetApi.prototype.updateValueAdHoc = function (values, bufferOption, updateOption, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/streamsets/value';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (values === null || values === undefined) {
                throw new Error('Required parameter values was null or undefined when calling updateValueAdHoc.');
            }
            if ((bufferOption !== undefined) && (bufferOption !== null)) {
                queryParameters['bufferOption'] = bufferOption;
            }
            if ((updateOption !== undefined) && (updateOption !== null)) {
                queryParameters['updateOption'] = updateOption;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = values;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return StreamSetApi;
    }());
    PIWebApiClient.StreamSetApi = StreamSetApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var SystemApi = (function () {
        function SystemApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        SystemApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        SystemApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        SystemApi.prototype.landing = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SystemApi.prototype.cacheInstances = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/cacheinstances';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SystemApi.prototype.status = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/status';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SystemApi.prototype.userInfo = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/userinfo';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        SystemApi.prototype.versions = function (extraHttpRequestParams) {
            var localVarPath = this.basePath + '/system/versions';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return SystemApi;
    }());
    PIWebApiClient.SystemApi = SystemApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var TableApi = (function () {
        function TableApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        TableApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        TableApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        TableApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.update = function (webId, table, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (table === null || table === undefined) {
                throw new Error('Required parameter table was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = table;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.getCategories = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/categories'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCategories.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.getData = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/data'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getData.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.updateData = function (webId, data, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/data'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateData.');
            }
            if (data === null || data === undefined) {
                throw new Error('Required parameter data was null or undefined when calling updateData.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = data;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tables/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return TableApi;
    }());
    PIWebApiClient.TableApi = TableApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var TableCategoryApi = (function () {
        function TableCategoryApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        TableCategoryApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        TableCategoryApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        TableCategoryApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.update = function (webId, tableCategory, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (tableCategory === null || tableCategory === undefined) {
                throw new Error('Required parameter tableCategory was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = tableCategory;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.getSecurity = function (webId, userIdentity, forceRefresh, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/security'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurity.');
            }
            if (userIdentity === null || userIdentity === undefined) {
                throw new Error('Required parameter userIdentity was null or undefined when calling getSecurity.');
            }
            if ((userIdentity !== undefined) && (userIdentity !== null)) {
                queryParameters['userIdentity'] = userIdentity;
            }
            if ((forceRefresh !== undefined) && (forceRefresh !== null)) {
                queryParameters['forceRefresh'] = forceRefresh;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.getSecurityEntries = function (webId, nameFilter, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntries.');
            }
            if ((nameFilter !== undefined) && (nameFilter !== null)) {
                queryParameters['nameFilter'] = nameFilter;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.createSecurityEntry = function (webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/securityentries'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling createSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.getSecurityEntryByName = function (name, webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling getSecurityEntryByName.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getSecurityEntryByName.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.updateSecurityEntry = function (name, webId, securityEntry, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling updateSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling updateSecurityEntry.');
            }
            if (securityEntry === null || securityEntry === undefined) {
                throw new Error('Required parameter securityEntry was null or undefined when calling updateSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PUT',
                headers: headerParams,
                processData: false
            };
            var reqDict = securityEntry;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TableCategoryApi.prototype.deleteSecurityEntry = function (name, webId, applyToChildren, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/tablecategories/{webId}/securityentries/{name}'
                .replace('{' + 'name' + '}', String(name))
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (name === null || name === undefined) {
                throw new Error('Required parameter name was null or undefined when calling deleteSecurityEntry.');
            }
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling deleteSecurityEntry.');
            }
            if ((applyToChildren !== undefined) && (applyToChildren !== null)) {
                queryParameters['applyToChildren'] = applyToChildren;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return TableCategoryApi;
    }());
    PIWebApiClient.TableCategoryApi = TableCategoryApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var TimeRuleApi = (function () {
        function TimeRuleApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        TimeRuleApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        TimeRuleApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        TimeRuleApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timerules';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TimeRuleApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timerules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TimeRuleApi.prototype.update = function (webId, timeRule, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timerules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (timeRule === null || timeRule === undefined) {
                throw new Error('Required parameter timeRule was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = timeRule;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TimeRuleApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timerules/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return TimeRuleApi;
    }());
    PIWebApiClient.TimeRuleApi = TimeRuleApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var TimeRulePlugInApi = (function () {
        function TimeRulePlugInApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        TimeRulePlugInApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        TimeRulePlugInApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        TimeRulePlugInApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timeruleplugins';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        TimeRulePlugInApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/timeruleplugins/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return TimeRulePlugInApi;
    }());
    PIWebApiClient.TimeRulePlugInApi = TimeRulePlugInApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var UnitApi = (function () {
        function UnitApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        UnitApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        UnitApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        UnitApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/units';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/units/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitApi.prototype.update = function (webId, unitDTO, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/units/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (unitDTO === null || unitDTO === undefined) {
                throw new Error('Required parameter unitDTO was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = unitDTO;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/units/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return UnitApi;
    }());
    PIWebApiClient.UnitApi = UnitApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var UnitClassApi = (function () {
        function UnitClassApi(basePath, ajaxOptions) {
            this.basePath = null;
            this.ajaxOptions = null;
            this.defaultHeaders = {};
            this.basePath = basePath;
            this.ajaxOptions = ajaxOptions;
        }
        UnitClassApi.prototype.applyAuthToRequest = function (requestOptions) {
            requestOptions.headers = this.ajaxOptions.headers;
            requestOptions.crossDomain = this.ajaxOptions.crossDomain;
            requestOptions.xhrFields = this.ajaxOptions.xhrFields;
        };
        UnitClassApi.prototype.extendObj = function (objA, objB) {
            for (var key in objB) {
                if (objB.hasOwnProperty(key)) {
                    objA[key] = objB[key];
                }
            }
            return objA;
        };
        UnitClassApi.prototype.getByPath = function (path, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses';
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (path === null || path === undefined) {
                throw new Error('Required parameter path was null or undefined when calling getByPath.');
            }
            if ((path !== undefined) && (path !== null)) {
                queryParameters['path'] = path;
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.get = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling get.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.update = function (webId, unitClassDTO, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling update.');
            }
            if (unitClassDTO === null || unitClassDTO === undefined) {
                throw new Error('Required parameter unitClassDTO was null or undefined when calling update.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'PATCH',
                headers: headerParams,
                processData: false
            };
            var reqDict = unitClassDTO;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.delete = function (webId, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling delete.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'DELETE',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.getCanonicalUnit = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}/canonicalunit'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getCanonicalUnit.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.getUnits = function (webId, selectedFields, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}/units'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling getUnits.');
            }
            if ((selectedFields !== undefined) && (selectedFields !== null)) {
                queryParameters['selectedFields'] = selectedFields;
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'GET',
                headers: headerParams,
                processData: false
            };
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        UnitClassApi.prototype.createUnit = function (webId, unitDTO, extraHttpRequestParams) {
            var localVarPath = this.basePath + '/unitclasses/{webId}/units'
                .replace('{' + 'webId' + '}', String(webId));
            var queryParameters = {};
            var headerParams = this.extendObj({}, this.defaultHeaders);
            if (webId === null || webId === undefined) {
                throw new Error('Required parameter webId was null or undefined when calling createUnit.');
            }
            if (unitDTO === null || unitDTO === undefined) {
                throw new Error('Required parameter unitDTO was null or undefined when calling createUnit.');
            }
            localVarPath = localVarPath + "?" + $.param(queryParameters);
            var requestOptions = {
                url: localVarPath,
                type: 'POST',
                headers: headerParams,
                processData: false
            };
            var reqDict = unitDTO;
            requestOptions.data = JSON.stringify(reqDict);
            requestOptions.contentType = 'application/json; charset=utf-8';
            this.applyAuthToRequest(requestOptions);
            var dfd = $.Deferred();
            $.ajax(requestOptions).then(function (data, textStatus, jqXHR) {
                return dfd.resolve({ response: jqXHR, data: data });
            }, function (xhr, textStatus, errorThrown) {
                return dfd.reject({ response: xhr, data: errorThrown });
            });
            return dfd.promise();
        };
        return UnitClassApi;
    }());
    PIWebApiClient.UnitClassApi = UnitClassApi;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnalysis = (function () {
        function PIAnalysis(webId, id, name, description, path, analysisRulePlugInName, autoCreated, categoryNames, groupId, hasNotification, hasTarget, hasTemplate, isConfigured, isTimeRuleDefinedByTemplate, maximumQueueSize, outputTime, priority, publishResults, status, targetWebId, templateName, timeRulePlugInName, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (analysisRulePlugInName != null) {
                this.AnalysisRulePlugInName = analysisRulePlugInName;
            }
            if (autoCreated != null) {
                this.AutoCreated = autoCreated;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (groupId != null) {
                this.GroupId = groupId;
            }
            if (hasNotification != null) {
                this.HasNotification = hasNotification;
            }
            if (hasTarget != null) {
                this.HasTarget = hasTarget;
            }
            if (hasTemplate != null) {
                this.HasTemplate = hasTemplate;
            }
            if (isConfigured != null) {
                this.IsConfigured = isConfigured;
            }
            if (isTimeRuleDefinedByTemplate != null) {
                this.IsTimeRuleDefinedByTemplate = isTimeRuleDefinedByTemplate;
            }
            if (maximumQueueSize != null) {
                this.MaximumQueueSize = maximumQueueSize;
            }
            if (outputTime != null) {
                this.OutputTime = outputTime;
            }
            if (priority != null) {
                this.Priority = priority;
            }
            if (publishResults != null) {
                this.PublishResults = publishResults;
            }
            if (status != null) {
                this.Status = status;
            }
            if (targetWebId != null) {
                this.TargetWebId = targetWebId;
            }
            if (templateName != null) {
                this.TemplateName = templateName;
            }
            if (timeRulePlugInName != null) {
                this.TimeRulePlugInName = timeRulePlugInName;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnalysis;
    }());
    PIWebApiClient.PIAnalysis = PIAnalysis;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnalysisCategory = (function () {
        function PIAnalysisCategory(webId, id, name, description, path, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnalysisCategory;
    }());
    PIWebApiClient.PIAnalysisCategory = PIAnalysisCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnalysisRule = (function () {
        function PIAnalysisRule(webId, id, name, description, path, configString, displayString, editorType, hasChildren, isConfigured, isInitializing, plugInName, supportedBehaviors, variableMapping, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (configString != null) {
                this.ConfigString = configString;
            }
            if (displayString != null) {
                this.DisplayString = displayString;
            }
            if (editorType != null) {
                this.EditorType = editorType;
            }
            if (hasChildren != null) {
                this.HasChildren = hasChildren;
            }
            if (isConfigured != null) {
                this.IsConfigured = isConfigured;
            }
            if (isInitializing != null) {
                this.IsInitializing = isInitializing;
            }
            if (plugInName != null) {
                this.PlugInName = plugInName;
            }
            if (supportedBehaviors != null) {
                this.SupportedBehaviors = supportedBehaviors;
            }
            if (variableMapping != null) {
                this.VariableMapping = variableMapping;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnalysisRule;
    }());
    PIWebApiClient.PIAnalysisRule = PIAnalysisRule;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnalysisRulePlugIn = (function () {
        function PIAnalysisRulePlugIn(webId, id, name, description, path, assemblyFileName, assemblyID, assemblyLoadProperties, assemblyTime, compatibilityVersion, isBrowsable, isNonEditableConfig, loadedAssemblyTime, loadedVersion, version, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (assemblyFileName != null) {
                this.AssemblyFileName = assemblyFileName;
            }
            if (assemblyID != null) {
                this.AssemblyID = assemblyID;
            }
            if (assemblyLoadProperties != null) {
                this.AssemblyLoadProperties = assemblyLoadProperties;
            }
            if (assemblyTime != null) {
                this.AssemblyTime = assemblyTime;
            }
            if (compatibilityVersion != null) {
                this.CompatibilityVersion = compatibilityVersion;
            }
            if (isBrowsable != null) {
                this.IsBrowsable = isBrowsable;
            }
            if (isNonEditableConfig != null) {
                this.IsNonEditableConfig = isNonEditableConfig;
            }
            if (loadedAssemblyTime != null) {
                this.LoadedAssemblyTime = loadedAssemblyTime;
            }
            if (loadedVersion != null) {
                this.LoadedVersion = loadedVersion;
            }
            if (version != null) {
                this.Version = version;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnalysisRulePlugIn;
    }());
    PIWebApiClient.PIAnalysisRulePlugIn = PIAnalysisRulePlugIn;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnalysisTemplate = (function () {
        function PIAnalysisTemplate(webId, id, name, description, path, analysisRulePlugInName, categoryNames, createEnabled, groupId, hasNotificationTemplate, hasTarget, outputTime, targetName, timeRulePlugInName, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (analysisRulePlugInName != null) {
                this.AnalysisRulePlugInName = analysisRulePlugInName;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (createEnabled != null) {
                this.CreateEnabled = createEnabled;
            }
            if (groupId != null) {
                this.GroupId = groupId;
            }
            if (hasNotificationTemplate != null) {
                this.HasNotificationTemplate = hasNotificationTemplate;
            }
            if (hasTarget != null) {
                this.HasTarget = hasTarget;
            }
            if (outputTime != null) {
                this.OutputTime = outputTime;
            }
            if (targetName != null) {
                this.TargetName = targetName;
            }
            if (timeRulePlugInName != null) {
                this.TimeRulePlugInName = timeRulePlugInName;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnalysisTemplate;
    }());
    PIWebApiClient.PIAnalysisTemplate = PIAnalysisTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAnnotation = (function () {
        function PIAnnotation(id, name, description, value, creator, creationDate, modifier, modifyDate, links) {
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (value != null) {
                this.Value = value;
            }
            if (creator != null) {
                this.Creator = creator;
            }
            if (creationDate != null) {
                this.CreationDate = creationDate;
            }
            if (modifier != null) {
                this.Modifier = modifier;
            }
            if (modifyDate != null) {
                this.ModifyDate = modifyDate;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAnnotation;
    }());
    PIWebApiClient.PIAnnotation = PIAnnotation;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAssetDatabase = (function () {
        function PIAssetDatabase(webId, id, name, description, path, extendedProperties, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (extendedProperties != null) {
                this.ExtendedProperties = extendedProperties;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAssetDatabase;
    }());
    PIWebApiClient.PIAssetDatabase = PIAssetDatabase;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAssetServer = (function () {
        function PIAssetServer(webId, id, name, description, path, isConnected, serverVersion, extendedProperties, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (isConnected != null) {
                this.IsConnected = isConnected;
            }
            if (serverVersion != null) {
                this.ServerVersion = serverVersion;
            }
            if (extendedProperties != null) {
                this.ExtendedProperties = extendedProperties;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAssetServer;
    }());
    PIWebApiClient.PIAssetServer = PIAssetServer;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAttribute = (function () {
        function PIAttribute(webId, id, name, description, path, type, typeQualifier, defaultUnitsName, dataReferencePlugIn, configString, isConfigurationItem, isExcluded, isHidden, isManualDataEntry, hasChildren, categoryNames, step, traitName, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (type != null) {
                this.Type = type;
            }
            if (typeQualifier != null) {
                this.TypeQualifier = typeQualifier;
            }
            if (defaultUnitsName != null) {
                this.DefaultUnitsName = defaultUnitsName;
            }
            if (dataReferencePlugIn != null) {
                this.DataReferencePlugIn = dataReferencePlugIn;
            }
            if (configString != null) {
                this.ConfigString = configString;
            }
            if (isConfigurationItem != null) {
                this.IsConfigurationItem = isConfigurationItem;
            }
            if (isExcluded != null) {
                this.IsExcluded = isExcluded;
            }
            if (isHidden != null) {
                this.IsHidden = isHidden;
            }
            if (isManualDataEntry != null) {
                this.IsManualDataEntry = isManualDataEntry;
            }
            if (hasChildren != null) {
                this.HasChildren = hasChildren;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (step != null) {
                this.Step = step;
            }
            if (traitName != null) {
                this.TraitName = traitName;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAttribute;
    }());
    PIWebApiClient.PIAttribute = PIAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAttributeCategory = (function () {
        function PIAttributeCategory(webId, id, name, description, path, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAttributeCategory;
    }());
    PIWebApiClient.PIAttributeCategory = PIAttributeCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAttributeTemplate = (function () {
        function PIAttributeTemplate(webId, id, name, description, path, type, typeQualifier, defaultUnitsName, defaultValue, dataReferencePlugIn, configString, isConfigurationItem, isExcluded, isHidden, isManualDataEntry, hasChildren, categoryNames, traitName, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (type != null) {
                this.Type = type;
            }
            if (typeQualifier != null) {
                this.TypeQualifier = typeQualifier;
            }
            if (defaultUnitsName != null) {
                this.DefaultUnitsName = defaultUnitsName;
            }
            if (defaultValue != null) {
                this.DefaultValue = defaultValue;
            }
            if (dataReferencePlugIn != null) {
                this.DataReferencePlugIn = dataReferencePlugIn;
            }
            if (configString != null) {
                this.ConfigString = configString;
            }
            if (isConfigurationItem != null) {
                this.IsConfigurationItem = isConfigurationItem;
            }
            if (isExcluded != null) {
                this.IsExcluded = isExcluded;
            }
            if (isHidden != null) {
                this.IsHidden = isHidden;
            }
            if (isManualDataEntry != null) {
                this.IsManualDataEntry = isManualDataEntry;
            }
            if (hasChildren != null) {
                this.HasChildren = hasChildren;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (traitName != null) {
                this.TraitName = traitName;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAttributeTemplate;
    }());
    PIWebApiClient.PIAttributeTemplate = PIAttributeTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAttributeTrait = (function () {
        function PIAttributeTrait(name, abbreviation, allowChildAttributes, allowDuplicates, isAllowedOnRootAttribute, isTypeInherited, isUOMInherited, requireNumeric, requireString, links) {
            if (name != null) {
                this.Name = name;
            }
            if (abbreviation != null) {
                this.Abbreviation = abbreviation;
            }
            if (allowChildAttributes != null) {
                this.AllowChildAttributes = allowChildAttributes;
            }
            if (allowDuplicates != null) {
                this.AllowDuplicates = allowDuplicates;
            }
            if (isAllowedOnRootAttribute != null) {
                this.IsAllowedOnRootAttribute = isAllowedOnRootAttribute;
            }
            if (isTypeInherited != null) {
                this.IsTypeInherited = isTypeInherited;
            }
            if (isUOMInherited != null) {
                this.IsUOMInherited = isUOMInherited;
            }
            if (requireNumeric != null) {
                this.RequireNumeric = requireNumeric;
            }
            if (requireString != null) {
                this.RequireString = requireString;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIAttributeTrait;
    }());
    PIWebApiClient.PIAttributeTrait = PIAttributeTrait;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIAttributeValueQuery = (function () {
        function PIAttributeValueQuery(attributeName, attributeValue, attributeUOM, searchOperator) {
            if (attributeName != null) {
                this.AttributeName = attributeName;
            }
            if (attributeValue != null) {
                this.AttributeValue = attributeValue;
            }
            if (attributeUOM != null) {
                this.AttributeUOM = attributeUOM;
            }
            if (searchOperator != null) {
                this.SearchOperator = searchOperator;
            }
        }
        return PIAttributeValueQuery;
    }());
    PIWebApiClient.PIAttributeValueQuery = PIAttributeValueQuery;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PICacheInstance = (function () {
        function PICacheInstance(id, lastRefreshTime, willRefreshAfter, scheduledExpirationTime, user) {
            if (id != null) {
                this.Id = id;
            }
            if (lastRefreshTime != null) {
                this.LastRefreshTime = lastRefreshTime;
            }
            if (willRefreshAfter != null) {
                this.WillRefreshAfter = willRefreshAfter;
            }
            if (scheduledExpirationTime != null) {
                this.ScheduledExpirationTime = scheduledExpirationTime;
            }
            if (user != null) {
                this.User = user;
            }
        }
        return PICacheInstance;
    }());
    PIWebApiClient.PICacheInstance = PICacheInstance;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIDataServer = (function () {
        function PIDataServer(webId, id, name, path, isConnected, serverVersion, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (path != null) {
                this.Path = path;
            }
            if (isConnected != null) {
                this.IsConnected = isConnected;
            }
            if (serverVersion != null) {
                this.ServerVersion = serverVersion;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIDataServer;
    }());
    PIWebApiClient.PIDataServer = PIDataServer;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIElement = (function () {
        function PIElement(webId, id, name, description, path, templateName, hasChildren, categoryNames, extendedProperties, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (templateName != null) {
                this.TemplateName = templateName;
            }
            if (hasChildren != null) {
                this.HasChildren = hasChildren;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (extendedProperties != null) {
                this.ExtendedProperties = extendedProperties;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIElement;
    }());
    PIWebApiClient.PIElement = PIElement;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIElementCategory = (function () {
        function PIElementCategory(webId, id, name, description, path, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIElementCategory;
    }());
    PIWebApiClient.PIElementCategory = PIElementCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIElementTemplate = (function () {
        function PIElementTemplate(webId, id, name, description, path, allowElementToExtend, baseTemplate, instanceType, namingPattern, categoryNames, extendedProperties, severity, canBeAcknowledged, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (allowElementToExtend != null) {
                this.AllowElementToExtend = allowElementToExtend;
            }
            if (baseTemplate != null) {
                this.BaseTemplate = baseTemplate;
            }
            if (instanceType != null) {
                this.InstanceType = instanceType;
            }
            if (namingPattern != null) {
                this.NamingPattern = namingPattern;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (extendedProperties != null) {
                this.ExtendedProperties = extendedProperties;
            }
            if (severity != null) {
                this.Severity = severity;
            }
            if (canBeAcknowledged != null) {
                this.CanBeAcknowledged = canBeAcknowledged;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIElementTemplate;
    }());
    PIWebApiClient.PIElementTemplate = PIElementTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIEnumerationSet = (function () {
        function PIEnumerationSet(webId, id, name, description, path, links, serializeDescription) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
            if (serializeDescription != null) {
                this.SerializeDescription = serializeDescription;
            }
        }
        return PIEnumerationSet;
    }());
    PIWebApiClient.PIEnumerationSet = PIEnumerationSet;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIEnumerationValue = (function () {
        function PIEnumerationValue(webId, id, name, description, value, path, links, serializeWebId, serializeId, serializeDescription, serializePath, serializeLinks) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (value != null) {
                this.Value = value;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
            if (serializeWebId != null) {
                this.SerializeWebId = serializeWebId;
            }
            if (serializeId != null) {
                this.SerializeId = serializeId;
            }
            if (serializeDescription != null) {
                this.SerializeDescription = serializeDescription;
            }
            if (serializePath != null) {
                this.SerializePath = serializePath;
            }
            if (serializeLinks != null) {
                this.SerializeLinks = serializeLinks;
            }
        }
        return PIEnumerationValue;
    }());
    PIWebApiClient.PIEnumerationValue = PIEnumerationValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIErrors = (function () {
        function PIErrors(errors) {
            if (errors != null) {
                this.Errors = errors;
            }
        }
        return PIErrors;
    }());
    PIWebApiClient.PIErrors = PIErrors;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIEventFrame = (function () {
        function PIEventFrame(webId, id, name, description, path, templateName, hasChildren, categoryNames, extendedProperties, startTime, endTime, severity, acknowledgedBy, acknowledgedDate, canBeAcknowledged, isAcknowledged, isAnnotated, isLocked, areValuesCaptured, refElementWebIds, security, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (templateName != null) {
                this.TemplateName = templateName;
            }
            if (hasChildren != null) {
                this.HasChildren = hasChildren;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (extendedProperties != null) {
                this.ExtendedProperties = extendedProperties;
            }
            if (startTime != null) {
                this.StartTime = startTime;
            }
            if (endTime != null) {
                this.EndTime = endTime;
            }
            if (severity != null) {
                this.Severity = severity;
            }
            if (acknowledgedBy != null) {
                this.AcknowledgedBy = acknowledgedBy;
            }
            if (acknowledgedDate != null) {
                this.AcknowledgedDate = acknowledgedDate;
            }
            if (canBeAcknowledged != null) {
                this.CanBeAcknowledged = canBeAcknowledged;
            }
            if (isAcknowledged != null) {
                this.IsAcknowledged = isAcknowledged;
            }
            if (isAnnotated != null) {
                this.IsAnnotated = isAnnotated;
            }
            if (isLocked != null) {
                this.IsLocked = isLocked;
            }
            if (areValuesCaptured != null) {
                this.AreValuesCaptured = areValuesCaptured;
            }
            if (refElementWebIds != null) {
                this.RefElementWebIds = refElementWebIds;
            }
            if (security != null) {
                this.Security = security;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIEventFrame;
    }());
    PIWebApiClient.PIEventFrame = PIEventFrame;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemAttribute = (function () {
        function PIItemAttribute(identifier, identifierType, object, exception) {
            if (identifier != null) {
                this.Identifier = identifier;
            }
            if (identifierType != null) {
                this.IdentifierType = identifierType;
            }
            if (object != null) {
                this.Object = object;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PIItemAttribute;
    }());
    PIWebApiClient.PIItemAttribute = PIItemAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemElement = (function () {
        function PIItemElement(identifier, identifierType, object, exception) {
            if (identifier != null) {
                this.Identifier = identifier;
            }
            if (identifierType != null) {
                this.IdentifierType = identifierType;
            }
            if (object != null) {
                this.Object = object;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PIItemElement;
    }());
    PIWebApiClient.PIItemElement = PIItemElement;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemEventFrame = (function () {
        function PIItemEventFrame(identifier, identifierType, object, exception) {
            if (identifier != null) {
                this.Identifier = identifier;
            }
            if (identifierType != null) {
                this.IdentifierType = identifierType;
            }
            if (object != null) {
                this.Object = object;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PIItemEventFrame;
    }());
    PIWebApiClient.PIItemEventFrame = PIItemEventFrame;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemPoint = (function () {
        function PIItemPoint(identifier, identifierType, object, exception) {
            if (identifier != null) {
                this.Identifier = identifier;
            }
            if (identifierType != null) {
                this.IdentifierType = identifierType;
            }
            if (object != null) {
                this.Object = object;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PIItemPoint;
    }());
    PIWebApiClient.PIItemPoint = PIItemPoint;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnalysis = (function () {
        function PIItemsAnalysis(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnalysis;
    }());
    PIWebApiClient.PIItemsAnalysis = PIItemsAnalysis;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnalysisCategory = (function () {
        function PIItemsAnalysisCategory(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnalysisCategory;
    }());
    PIWebApiClient.PIItemsAnalysisCategory = PIItemsAnalysisCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnalysisRule = (function () {
        function PIItemsAnalysisRule(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnalysisRule;
    }());
    PIWebApiClient.PIItemsAnalysisRule = PIItemsAnalysisRule;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnalysisRulePlugIn = (function () {
        function PIItemsAnalysisRulePlugIn(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnalysisRulePlugIn;
    }());
    PIWebApiClient.PIItemsAnalysisRulePlugIn = PIItemsAnalysisRulePlugIn;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnalysisTemplate = (function () {
        function PIItemsAnalysisTemplate(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnalysisTemplate;
    }());
    PIWebApiClient.PIItemsAnalysisTemplate = PIItemsAnalysisTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAnnotation = (function () {
        function PIItemsAnnotation(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAnnotation;
    }());
    PIWebApiClient.PIItemsAnnotation = PIItemsAnnotation;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAssetDatabase = (function () {
        function PIItemsAssetDatabase(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAssetDatabase;
    }());
    PIWebApiClient.PIItemsAssetDatabase = PIItemsAssetDatabase;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAssetServer = (function () {
        function PIItemsAssetServer(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAssetServer;
    }());
    PIWebApiClient.PIItemsAssetServer = PIItemsAssetServer;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAttribute = (function () {
        function PIItemsAttribute(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAttribute;
    }());
    PIWebApiClient.PIItemsAttribute = PIItemsAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAttributeCategory = (function () {
        function PIItemsAttributeCategory(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAttributeCategory;
    }());
    PIWebApiClient.PIItemsAttributeCategory = PIItemsAttributeCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAttributeTemplate = (function () {
        function PIItemsAttributeTemplate(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAttributeTemplate;
    }());
    PIWebApiClient.PIItemsAttributeTemplate = PIItemsAttributeTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsAttributeTrait = (function () {
        function PIItemsAttributeTrait(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsAttributeTrait;
    }());
    PIWebApiClient.PIItemsAttributeTrait = PIItemsAttributeTrait;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsCacheInstance = (function () {
        function PIItemsCacheInstance(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsCacheInstance;
    }());
    PIWebApiClient.PIItemsCacheInstance = PIItemsCacheInstance;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsDataServer = (function () {
        function PIItemsDataServer(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsDataServer;
    }());
    PIWebApiClient.PIItemsDataServer = PIItemsDataServer;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsElement = (function () {
        function PIItemsElement(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsElement;
    }());
    PIWebApiClient.PIItemsElement = PIItemsElement;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsElementCategory = (function () {
        function PIItemsElementCategory(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsElementCategory;
    }());
    PIWebApiClient.PIItemsElementCategory = PIItemsElementCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsElementTemplate = (function () {
        function PIItemsElementTemplate(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsElementTemplate;
    }());
    PIWebApiClient.PIItemsElementTemplate = PIItemsElementTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsEnumerationSet = (function () {
        function PIItemsEnumerationSet(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsEnumerationSet;
    }());
    PIWebApiClient.PIItemsEnumerationSet = PIItemsEnumerationSet;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsEnumerationValue = (function () {
        function PIItemsEnumerationValue(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsEnumerationValue;
    }());
    PIWebApiClient.PIItemsEnumerationValue = PIItemsEnumerationValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsEventFrame = (function () {
        function PIItemsEventFrame(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsEventFrame;
    }());
    PIWebApiClient.PIItemsEventFrame = PIItemsEventFrame;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsItemAttribute = (function () {
        function PIItemsItemAttribute(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsItemAttribute;
    }());
    PIWebApiClient.PIItemsItemAttribute = PIItemsItemAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsItemElement = (function () {
        function PIItemsItemElement(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsItemElement;
    }());
    PIWebApiClient.PIItemsItemElement = PIItemsItemElement;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsItemEventFrame = (function () {
        function PIItemsItemEventFrame(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsItemEventFrame;
    }());
    PIWebApiClient.PIItemsItemEventFrame = PIItemsItemEventFrame;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsItemPoint = (function () {
        function PIItemsItemPoint(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsItemPoint;
    }());
    PIWebApiClient.PIItemsItemPoint = PIItemsItemPoint;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsItemsSubstatus = (function () {
        function PIItemsItemsSubstatus(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsItemsSubstatus;
    }());
    PIWebApiClient.PIItemsItemsSubstatus = PIItemsItemsSubstatus;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsPoint = (function () {
        function PIItemsPoint(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsPoint;
    }());
    PIWebApiClient.PIItemsPoint = PIItemsPoint;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsPointAttribute = (function () {
        function PIItemsPointAttribute(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsPointAttribute;
    }());
    PIWebApiClient.PIItemsPointAttribute = PIItemsPointAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSecurityEntry = (function () {
        function PIItemsSecurityEntry(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSecurityEntry;
    }());
    PIWebApiClient.PIItemsSecurityEntry = PIItemsSecurityEntry;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSecurityIdentity = (function () {
        function PIItemsSecurityIdentity(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSecurityIdentity;
    }());
    PIWebApiClient.PIItemsSecurityIdentity = PIItemsSecurityIdentity;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSecurityMapping = (function () {
        function PIItemsSecurityMapping(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSecurityMapping;
    }());
    PIWebApiClient.PIItemsSecurityMapping = PIItemsSecurityMapping;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSecurityRights = (function () {
        function PIItemsSecurityRights(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSecurityRights;
    }());
    PIWebApiClient.PIItemsSecurityRights = PIItemsSecurityRights;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsStreamSummaries = (function () {
        function PIItemsStreamSummaries(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsStreamSummaries;
    }());
    PIWebApiClient.PIItemsStreamSummaries = PIItemsStreamSummaries;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsStreamValue = (function () {
        function PIItemsStreamValue(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsStreamValue;
    }());
    PIWebApiClient.PIItemsStreamValue = PIItemsStreamValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsStreamValues = (function () {
        function PIItemsStreamValues(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsStreamValues;
    }());
    PIWebApiClient.PIItemsStreamValues = PIItemsStreamValues;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSubstatus = (function () {
        function PIItemsSubstatus(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSubstatus;
    }());
    PIWebApiClient.PIItemsSubstatus = PIItemsSubstatus;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsSummaryValue = (function () {
        function PIItemsSummaryValue(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsSummaryValue;
    }());
    PIWebApiClient.PIItemsSummaryValue = PIItemsSummaryValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsTable = (function () {
        function PIItemsTable(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsTable;
    }());
    PIWebApiClient.PIItemsTable = PIItemsTable;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsTableCategory = (function () {
        function PIItemsTableCategory(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsTableCategory;
    }());
    PIWebApiClient.PIItemsTableCategory = PIItemsTableCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsTimeRulePlugIn = (function () {
        function PIItemsTimeRulePlugIn(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsTimeRulePlugIn;
    }());
    PIWebApiClient.PIItemsTimeRulePlugIn = PIItemsTimeRulePlugIn;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIItemsUnitClass = (function () {
        function PIItemsUnitClass(items, links) {
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIItemsUnitClass;
    }());
    PIWebApiClient.PIItemsUnitClass = PIItemsUnitClass;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PILanding = (function () {
        function PILanding(links) {
            if (links != null) {
                this.Links = links;
            }
        }
        return PILanding;
    }());
    PIWebApiClient.PILanding = PILanding;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIPoint = (function () {
        function PIPoint(webId, id, name, path, descriptor, pointClass, pointType, digitalSetName, engineeringUnits, step, future, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (path != null) {
                this.Path = path;
            }
            if (descriptor != null) {
                this.Descriptor = descriptor;
            }
            if (pointClass != null) {
                this.PointClass = pointClass;
            }
            if (pointType != null) {
                this.PointType = pointType;
            }
            if (digitalSetName != null) {
                this.DigitalSetName = digitalSetName;
            }
            if (engineeringUnits != null) {
                this.EngineeringUnits = engineeringUnits;
            }
            if (step != null) {
                this.Step = step;
            }
            if (future != null) {
                this.Future = future;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIPoint;
    }());
    PIWebApiClient.PIPoint = PIPoint;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIPointAttribute = (function () {
        function PIPointAttribute(name, value, links) {
            if (name != null) {
                this.Name = name;
            }
            if (value != null) {
                this.Value = value;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIPointAttribute;
    }());
    PIWebApiClient.PIPointAttribute = PIPointAttribute;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIRequest = (function () {
        function PIRequest(method, resource, requestTemplate, parameters, headers, content, parentIds) {
            if (method != null) {
                this.Method = method;
            }
            if (resource != null) {
                this.Resource = resource;
            }
            if (requestTemplate != null) {
                this.RequestTemplate = requestTemplate;
            }
            if (parameters != null) {
                this.Parameters = parameters;
            }
            if (headers != null) {
                this.Headers = headers;
            }
            if (content != null) {
                this.Content = content;
            }
            if (parentIds != null) {
                this.ParentIds = parentIds;
            }
        }
        return PIRequest;
    }());
    PIWebApiClient.PIRequest = PIRequest;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIRequestTemplate = (function () {
        function PIRequestTemplate(resource) {
            if (resource != null) {
                this.Resource = resource;
            }
        }
        return PIRequestTemplate;
    }());
    PIWebApiClient.PIRequestTemplate = PIRequestTemplate;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIResponse = (function () {
        function PIResponse(status, headers, content) {
            if (status != null) {
                this.Status = status;
            }
            if (headers != null) {
                this.Headers = headers;
            }
            if (content != null) {
                this.Content = content;
            }
        }
        return PIResponse;
    }());
    PIWebApiClient.PIResponse = PIResponse;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISearchByAttributeElement = (function () {
        function PISearchByAttributeElement(searchRoot, elementTemplate, valueQueries) {
            if (searchRoot != null) {
                this.SearchRoot = searchRoot;
            }
            if (elementTemplate != null) {
                this.ElementTemplate = elementTemplate;
            }
            if (valueQueries != null) {
                this.ValueQueries = valueQueries;
            }
        }
        return PISearchByAttributeElement;
    }());
    PIWebApiClient.PISearchByAttributeElement = PISearchByAttributeElement;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISearchByAttributeEventFrame = (function () {
        function PISearchByAttributeEventFrame(searchRoot, elementTemplate, valueQueries) {
            if (searchRoot != null) {
                this.SearchRoot = searchRoot;
            }
            if (elementTemplate != null) {
                this.ElementTemplate = elementTemplate;
            }
            if (valueQueries != null) {
                this.ValueQueries = valueQueries;
            }
        }
        return PISearchByAttributeEventFrame;
    }());
    PIWebApiClient.PISearchByAttributeEventFrame = PISearchByAttributeEventFrame;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISecurity = (function () {
        function PISecurity(canAnnotate, canDelete, canExecute, canRead, canReadData, canSubscribe, canSubscribeOthers, canWrite, canWriteData, hasAdmin, rights) {
            if (canAnnotate != null) {
                this.CanAnnotate = canAnnotate;
            }
            if (canDelete != null) {
                this.CanDelete = canDelete;
            }
            if (canExecute != null) {
                this.CanExecute = canExecute;
            }
            if (canRead != null) {
                this.CanRead = canRead;
            }
            if (canReadData != null) {
                this.CanReadData = canReadData;
            }
            if (canSubscribe != null) {
                this.CanSubscribe = canSubscribe;
            }
            if (canSubscribeOthers != null) {
                this.CanSubscribeOthers = canSubscribeOthers;
            }
            if (canWrite != null) {
                this.CanWrite = canWrite;
            }
            if (canWriteData != null) {
                this.CanWriteData = canWriteData;
            }
            if (hasAdmin != null) {
                this.HasAdmin = hasAdmin;
            }
            if (rights != null) {
                this.Rights = rights;
            }
        }
        return PISecurity;
    }());
    PIWebApiClient.PISecurity = PISecurity;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISecurityEntry = (function () {
        function PISecurityEntry(name, securityIdentityName, allowRights, denyRights, links) {
            if (name != null) {
                this.Name = name;
            }
            if (securityIdentityName != null) {
                this.SecurityIdentityName = securityIdentityName;
            }
            if (allowRights != null) {
                this.AllowRights = allowRights;
            }
            if (denyRights != null) {
                this.DenyRights = denyRights;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PISecurityEntry;
    }());
    PIWebApiClient.PISecurityEntry = PISecurityEntry;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISecurityIdentity = (function () {
        function PISecurityIdentity(webId, id, name, description, path, isEnabled, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (isEnabled != null) {
                this.IsEnabled = isEnabled;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PISecurityIdentity;
    }());
    PIWebApiClient.PISecurityIdentity = PISecurityIdentity;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISecurityMapping = (function () {
        function PISecurityMapping(webId, id, name, description, path, account, securityIdentityWebId, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (account != null) {
                this.Account = account;
            }
            if (securityIdentityWebId != null) {
                this.SecurityIdentityWebId = securityIdentityWebId;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PISecurityMapping;
    }());
    PIWebApiClient.PISecurityMapping = PISecurityMapping;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISecurityRights = (function () {
        function PISecurityRights(ownerWebId, securityItem, userIdentity, links) {
            if (ownerWebId != null) {
                this.OwnerWebId = ownerWebId;
            }
            if (securityItem != null) {
                this.SecurityItem = securityItem;
            }
            if (userIdentity != null) {
                this.UserIdentity = userIdentity;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PISecurityRights;
    }());
    PIWebApiClient.PISecurityRights = PISecurityRights;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIStreamSummaries = (function () {
        function PIStreamSummaries(webId, name, path, items, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (name != null) {
                this.Name = name;
            }
            if (path != null) {
                this.Path = path;
            }
            if (items != null) {
                this.Items = items;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIStreamSummaries;
    }());
    PIWebApiClient.PIStreamSummaries = PIStreamSummaries;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIStreamValue = (function () {
        function PIStreamValue(webId, name, path, value, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (name != null) {
                this.Name = name;
            }
            if (path != null) {
                this.Path = path;
            }
            if (value != null) {
                this.Value = value;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIStreamValue;
    }());
    PIWebApiClient.PIStreamValue = PIStreamValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIStreamValues = (function () {
        function PIStreamValues(webId, name, path, items, unitsAbbreviation, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (name != null) {
                this.Name = name;
            }
            if (path != null) {
                this.Path = path;
            }
            if (items != null) {
                this.Items = items;
            }
            if (unitsAbbreviation != null) {
                this.UnitsAbbreviation = unitsAbbreviation;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIStreamValues;
    }());
    PIWebApiClient.PIStreamValues = PIStreamValues;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISubstatus = (function () {
        function PISubstatus(substatus, message) {
            if (substatus != null) {
                this.Substatus = substatus;
            }
            if (message != null) {
                this.Message = message;
            }
        }
        return PISubstatus;
    }());
    PIWebApiClient.PISubstatus = PISubstatus;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISummaryValue = (function () {
        function PISummaryValue(type, value) {
            if (type != null) {
                this.Type = type;
            }
            if (value != null) {
                this.Value = value;
            }
        }
        return PISummaryValue;
    }());
    PIWebApiClient.PISummaryValue = PISummaryValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISystemLanding = (function () {
        function PISystemLanding(productTitle, productVersion, links) {
            if (productTitle != null) {
                this.ProductTitle = productTitle;
            }
            if (productVersion != null) {
                this.ProductVersion = productVersion;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PISystemLanding;
    }());
    PIWebApiClient.PISystemLanding = PISystemLanding;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PISystemStatus = (function () {
        function PISystemStatus(upTimeInMinutes, state, cacheInstances) {
            if (upTimeInMinutes != null) {
                this.UpTimeInMinutes = upTimeInMinutes;
            }
            if (state != null) {
                this.State = state;
            }
            if (cacheInstances != null) {
                this.CacheInstances = cacheInstances;
            }
        }
        return PISystemStatus;
    }());
    PIWebApiClient.PISystemStatus = PISystemStatus;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITable = (function () {
        function PITable(webId, id, name, description, path, categoryNames, timeZone, convertToLocalTime, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (categoryNames != null) {
                this.CategoryNames = categoryNames;
            }
            if (timeZone != null) {
                this.TimeZone = timeZone;
            }
            if (convertToLocalTime != null) {
                this.ConvertToLocalTime = convertToLocalTime;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PITable;
    }());
    PIWebApiClient.PITable = PITable;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITableCategory = (function () {
        function PITableCategory(webId, id, name, description, path, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PITableCategory;
    }());
    PIWebApiClient.PITableCategory = PITableCategory;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITableData = (function () {
        function PITableData(columns, rows) {
            if (columns != null) {
                this.Columns = columns;
            }
            if (rows != null) {
                this.Rows = rows;
            }
        }
        return PITableData;
    }());
    PIWebApiClient.PITableData = PITableData;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITimedValue = (function () {
        function PITimedValue(timestamp, unitsAbbreviation, good, questionable, substituted, value, exception) {
            if (timestamp != null) {
                this.Timestamp = timestamp;
            }
            if (unitsAbbreviation != null) {
                this.UnitsAbbreviation = unitsAbbreviation;
            }
            if (good != null) {
                this.Good = good;
            }
            if (questionable != null) {
                this.Questionable = questionable;
            }
            if (substituted != null) {
                this.Substituted = substituted;
            }
            if (value != null) {
                this.Value = value;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PITimedValue;
    }());
    PIWebApiClient.PITimedValue = PITimedValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITimedValues = (function () {
        function PITimedValues(items, unitsAbbreviation) {
            if (items != null) {
                this.Items = items;
            }
            if (unitsAbbreviation != null) {
                this.UnitsAbbreviation = unitsAbbreviation;
            }
        }
        return PITimedValues;
    }());
    PIWebApiClient.PITimedValues = PITimedValues;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITimeRule = (function () {
        function PITimeRule(webId, id, name, description, path, configString, configStringStored, displayString, editorType, isConfigured, isInitializing, mergeDuplicatedItems, plugInName, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (configString != null) {
                this.ConfigString = configString;
            }
            if (configStringStored != null) {
                this.ConfigStringStored = configStringStored;
            }
            if (displayString != null) {
                this.DisplayString = displayString;
            }
            if (editorType != null) {
                this.EditorType = editorType;
            }
            if (isConfigured != null) {
                this.IsConfigured = isConfigured;
            }
            if (isInitializing != null) {
                this.IsInitializing = isInitializing;
            }
            if (mergeDuplicatedItems != null) {
                this.MergeDuplicatedItems = mergeDuplicatedItems;
            }
            if (plugInName != null) {
                this.PlugInName = plugInName;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PITimeRule;
    }());
    PIWebApiClient.PITimeRule = PITimeRule;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PITimeRulePlugIn = (function () {
        function PITimeRulePlugIn(webId, id, name, description, path, assemblyFileName, assemblyID, assemblyLoadProperties, assemblyTime, compatibilityVersion, isBrowsable, isNonEditableConfig, loadedAssemblyTime, loadedVersion, version, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (assemblyFileName != null) {
                this.AssemblyFileName = assemblyFileName;
            }
            if (assemblyID != null) {
                this.AssemblyID = assemblyID;
            }
            if (assemblyLoadProperties != null) {
                this.AssemblyLoadProperties = assemblyLoadProperties;
            }
            if (assemblyTime != null) {
                this.AssemblyTime = assemblyTime;
            }
            if (compatibilityVersion != null) {
                this.CompatibilityVersion = compatibilityVersion;
            }
            if (isBrowsable != null) {
                this.IsBrowsable = isBrowsable;
            }
            if (isNonEditableConfig != null) {
                this.IsNonEditableConfig = isNonEditableConfig;
            }
            if (loadedAssemblyTime != null) {
                this.LoadedAssemblyTime = loadedAssemblyTime;
            }
            if (loadedVersion != null) {
                this.LoadedVersion = loadedVersion;
            }
            if (version != null) {
                this.Version = version;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PITimeRulePlugIn;
    }());
    PIWebApiClient.PITimeRulePlugIn = PITimeRulePlugIn;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIUnit = (function () {
        function PIUnit(webId, id, name, abbreviation, description, path, factor, offset, referenceFactor, referenceOffset, referenceUnitAbbreviation, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (abbreviation != null) {
                this.Abbreviation = abbreviation;
            }
            if (description != null) {
                this.Description = description;
            }
            if (path != null) {
                this.Path = path;
            }
            if (factor != null) {
                this.Factor = factor;
            }
            if (offset != null) {
                this.Offset = offset;
            }
            if (referenceFactor != null) {
                this.ReferenceFactor = referenceFactor;
            }
            if (referenceOffset != null) {
                this.ReferenceOffset = referenceOffset;
            }
            if (referenceUnitAbbreviation != null) {
                this.ReferenceUnitAbbreviation = referenceUnitAbbreviation;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIUnit;
    }());
    PIWebApiClient.PIUnit = PIUnit;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIUnitClass = (function () {
        function PIUnitClass(webId, id, name, description, canonicalUnitName, canonicalUnitAbbreviation, path, links) {
            if (webId != null) {
                this.WebId = webId;
            }
            if (id != null) {
                this.Id = id;
            }
            if (name != null) {
                this.Name = name;
            }
            if (description != null) {
                this.Description = description;
            }
            if (canonicalUnitName != null) {
                this.CanonicalUnitName = canonicalUnitName;
            }
            if (canonicalUnitAbbreviation != null) {
                this.CanonicalUnitAbbreviation = canonicalUnitAbbreviation;
            }
            if (path != null) {
                this.Path = path;
            }
            if (links != null) {
                this.Links = links;
            }
        }
        return PIUnitClass;
    }());
    PIWebApiClient.PIUnitClass = PIUnitClass;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIUserInfo = (function () {
        function PIUserInfo(identityType, name, isAuthenticated, sID, impersonationLevel) {
            if (identityType != null) {
                this.IdentityType = identityType;
            }
            if (name != null) {
                this.Name = name;
            }
            if (isAuthenticated != null) {
                this.IsAuthenticated = isAuthenticated;
            }
            if (sID != null) {
                this.SID = sID;
            }
            if (impersonationLevel != null) {
                this.ImpersonationLevel = impersonationLevel;
            }
        }
        return PIUserInfo;
    }());
    PIWebApiClient.PIUserInfo = PIUserInfo;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIValue = (function () {
        function PIValue(value, exception) {
            if (value != null) {
                this.Value = value;
            }
            if (exception != null) {
                this.Exception = exception;
            }
        }
        return PIValue;
    }());
    PIWebApiClient.PIValue = PIValue;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="../api.d.ts"/>
var PIWebApiClient;
(function (PIWebApiClient) {
    'use strict';
    var PIVersion = (function () {
        function PIVersion(fullVersion, majorMinorRevision, build) {
            if (fullVersion != null) {
                this.FullVersion = fullVersion;
            }
            if (majorMinorRevision != null) {
                this.MajorMinorRevision = majorMinorRevision;
            }
            if (build != null) {
                this.Build = build;
            }
        }
        return PIVersion;
    }());
    PIWebApiClient.PIVersion = PIVersion;
})(PIWebApiClient || (PIWebApiClient = {}));

/**
* Copyright 2017 OSIsoft, LLC
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*  <http://www.apache.org/licenses/LICENSE-2.0>
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/// <reference path="api.d.ts"/>
var PIWebApi = (function () {
    function PIWebApi(basePath, useKerberos, username, password) {
        this.basePath = basePath;
        this.useKerberos = useKerberos;
        this.ajaxOptions = {
            crossDomain: true,
            xhrFields: {
                withCredentials: true
            }
        };
        if (this.useKerberos == false) {
            this.ajaxOptions.headers = {
                "Authorization": "Basic " + btoa(username + ":" + password)
            };
        }
        this.analysis = new PIWebApiClient.AnalysisApi(this.basePath, this.ajaxOptions);
        this.analysisCategory = new PIWebApiClient.AnalysisCategoryApi(this.basePath, this.ajaxOptions);
        this.analysisRule = new PIWebApiClient.AnalysisRuleApi(this.basePath, this.ajaxOptions);
        this.analysisRulePlugIn = new PIWebApiClient.AnalysisRulePlugInApi(this.basePath, this.ajaxOptions);
        this.analysisTemplate = new PIWebApiClient.AnalysisTemplateApi(this.basePath, this.ajaxOptions);
        this.assetDatabase = new PIWebApiClient.AssetDatabaseApi(this.basePath, this.ajaxOptions);
        this.assetServer = new PIWebApiClient.AssetServerApi(this.basePath, this.ajaxOptions);
        this.attribute = new PIWebApiClient.AttributeApi(this.basePath, this.ajaxOptions);
        this.attributeCategory = new PIWebApiClient.AttributeCategoryApi(this.basePath, this.ajaxOptions);
        this.attributeTemplate = new PIWebApiClient.AttributeTemplateApi(this.basePath, this.ajaxOptions);
        this.attributeTrait = new PIWebApiClient.AttributeTraitApi(this.basePath, this.ajaxOptions);
        this.batch = new PIWebApiClient.BatchApi(this.basePath, this.ajaxOptions);
        this.calculation = new PIWebApiClient.CalculationApi(this.basePath, this.ajaxOptions);
        this.configuration = new PIWebApiClient.ConfigurationApi(this.basePath, this.ajaxOptions);
        this.dataServer = new PIWebApiClient.DataServerApi(this.basePath, this.ajaxOptions);
        this.element = new PIWebApiClient.ElementApi(this.basePath, this.ajaxOptions);
        this.elementCategory = new PIWebApiClient.ElementCategoryApi(this.basePath, this.ajaxOptions);
        this.elementTemplate = new PIWebApiClient.ElementTemplateApi(this.basePath, this.ajaxOptions);
        this.enumerationSet = new PIWebApiClient.EnumerationSetApi(this.basePath, this.ajaxOptions);
        this.enumerationValue = new PIWebApiClient.EnumerationValueApi(this.basePath, this.ajaxOptions);
        this.eventFrame = new PIWebApiClient.EventFrameApi(this.basePath, this.ajaxOptions);
        this.home = new PIWebApiClient.HomeApi(this.basePath, this.ajaxOptions);
        this.point = new PIWebApiClient.PointApi(this.basePath, this.ajaxOptions);
        this.securityIdentity = new PIWebApiClient.SecurityIdentityApi(this.basePath, this.ajaxOptions);
        this.securityMapping = new PIWebApiClient.SecurityMappingApi(this.basePath, this.ajaxOptions);
        this.stream = new PIWebApiClient.StreamApi(this.basePath, this.ajaxOptions);
        this.streamSet = new PIWebApiClient.StreamSetApi(this.basePath, this.ajaxOptions);
        this.system = new PIWebApiClient.SystemApi(this.basePath, this.ajaxOptions);
        this.table = new PIWebApiClient.TableApi(this.basePath, this.ajaxOptions);
        this.tableCategory = new PIWebApiClient.TableCategoryApi(this.basePath, this.ajaxOptions);
        this.timeRule = new PIWebApiClient.TimeRuleApi(this.basePath, this.ajaxOptions);
        this.timeRulePlugIn = new PIWebApiClient.TimeRulePlugInApi(this.basePath, this.ajaxOptions);
        this.unit = new PIWebApiClient.UnitApi(this.basePath, this.ajaxOptions);
        this.unitClass = new PIWebApiClient.UnitClassApi(this.basePath, this.ajaxOptions);
    }
    return PIWebApi;
}());
