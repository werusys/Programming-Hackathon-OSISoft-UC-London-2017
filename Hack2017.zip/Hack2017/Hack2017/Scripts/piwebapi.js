﻿var piwebapi = (function () {
    //var base_service_url = "NotDefined";
    var base_service_url = "https://saturn018.osiproghack.int/piwebapi/";

    function GetJsonContent(url, SuccessCallBack, ErrorCallBack) {
        $.ajax({
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST,PU,POSTT"
            },
            type: 'GET',
            url: url,
            cache: false,
            async: false,
            xhrFields: {
                withCredentials: true
            },
            //async: false, //temp. wg. IG Bug
            success: SuccessCallBack,
            error: ErrorCallBack

        });
    }


    //var options = {
    //    async: params.async != undefined ? params.async : true,
    //    type: "POST",
    //    url: params.url,
    //    data: params.data,
    //    cache: false,
    //    crossDomain: true,
    //    xhrFields: {
    //        withCredentials: true
    //    },
    //    success: params.successFunc,
    //    error: params.errorFunc
    //};

    //if (params.headers)
    //    options.headers = params.headers;

    //if (params.dataType)
    //    options.dataType = params.dataType;

    //return $.ajax(options);


    function PostJsonContent(url, content, SuccessCallBack, ErrorCallBack) {
        $.ajax({           
            type: 'POST',
            url: url,
            data: content,         
            async: false,
            xhrFields: {
                withCredentials: true
            },
            //async: false, //temp. wg. IG Bug
            success: SuccessCallBack,
            error: ErrorCallBack

        });
    }

    function CheckPIServerName(piServerName, UpdateDOM) {
        BaseUrlCheck();
        var url = base_service_url + "dataservers?name=" + piServerName;
        GetJsonContent(url, (function (piServerJsonData) {
            UpdateDOM(true);
        }), (function () {
            UpdateDOM(false);
        }));
    }


    function CheckPIPointName(piServerName, piPointName, UpdateDOM) {

        BaseUrlCheck();
        url = base_service_url + "points?path=\\\\" + piServerName + "\\" + piPointName;
        GetJsonContent(url, (function (piPointJsonData) {
            piPointLinksJsonData = piPointJsonData;
            UpdateDOM(true);
        }), (function () {
            UpdateDOM(false)
        }));
    }



    /* AB, 16.03.2016 */

    function GetAfTree(UpdateDOM) {

        var dataAssetPromise = GetAssetServer(base_service_url);

        dataAssetPromise.done(function (assetServers) {

            //

            //assetServers.Items.forEach(function (assetServer) {

            //    var dataDatabasePromise = GetDatabases(base_service_url, assetServer);

            //    dataDatabasePromise.done(function (databases) {

            //        assetServer.Items = databases.Items;

            //        
            //    });

            //});


            UpdateDOM(assetServers);
        });



    }

    function GetAfTreeData(url, UpdateDOM) {

        var dataPromise = GetPiWebApiData(url);

        dataPromise.done(function (data) {

            UpdateDOM(data);
        });

    }

    function GetAssetServer(url) {

        var dfd = jQuery.Deferred();

        GetJsonContent(url + '/assetservers',
            function (collection) {
                dfd.resolve(collection);
            },
            function (err) {
                dfd.fail(err);
            });

        return dfd.promise();
    }

    function GetPiWebApiData(url) {

        var dfd = jQuery.Deferred();

        GetJsonContent(url,
            function (collection) {
                dfd.resolve(collection);
            },
            function (err) {
                dfd.fail(err);
            });

        return dfd.promise();
    }

    function GetData(piServerName, piPointName, ServiceUrl, QueryString, UpdateDOM) {
        BaseUrlCheck();
        url = base_service_url + "points?path=\\\\" + piServerName + "\\" + piPointName;
        GetJsonContent(url, (function (piPointJsonData) {
            var url_data = piPointJsonData["Links"][ServiceUrl] + QueryString;
            GetJsonContent(url_data, (function (JsonData) {
                UpdateDOM(JsonData);
            }), (function () {
                UpdateDOM("Error: Parameters are incorrect.");
            }));
        }), (function () {
            UpdateDOM("Error: Could not find PI Point on the selected PI Data Archive.");
        }));
    }


    function GetJsonData(url) {

        var dfd = jQuery.Deferred();

        GetJsonContent(url,
            function (collection) {
                dfd.resolve(collection);
            },
            function (err) {
                dfd.fail(err);
            });

        return dfd.promise();
    }

    function BaseUrlCheck() {
        if (base_service_url == "NotDefined") {
            alert("Service base url was not defined");
        }
    }

    function WriteLog(text) {

        try {

            console.log(text);

        } catch (e) {

        }

    }

    return {
        ValidPIServerName: function (piServerName, UpdateDOM) {
            CheckPIServerName(piServerName, UpdateDOM);
        },

        ValidPIPointName: function (piServerName, piPointName, UpdateDOM) {
            CheckPIPointName(piServerName, piPointName, UpdateDOM);
        },

        GetSnapshotValue: function (piServerName, piPointName, UpdateDOM) {
            GetData(piServerName, piPointName, "Value", "", UpdateDOM);
        },
        GetRecordedValues: function (piServerName, piPointName, startTime, endTime, UpdateDOM) {
            GetData(piServerName, piPointName, "RecordedData", "?starttime=" + startTime + "&endtime=" + endTime, UpdateDOM);
        },
        GetInterpolatedValues: function (piServerName, piPointName, startTime, endTime, interval, UpdateDOM) {
            GetData(piServerName, piPointName, "InterpolatedData", "?starttime=" + startTime + "&endtime=" + endTime + "&interval=" + interval, UpdateDOM);
        },
        SetBaseServiceUrl: function (baseUrl) {
            base_service_url = baseUrl;
            if (base_service_url.slice(-1) != "/") {
                base_service_url = base_service_url + "/";
            }
        },

        GetAfTree: function (UpdateDOM) {
            GetAfTree(UpdateDOM);
        },

        GetAfTreeData: function (url, UpdateDOM) {
            GetAfTreeData(url, UpdateDOM);
        },

        GetJsonData: function (url) {
            return GetJsonData(url);
        },

        WriteLog: function (text) {
            WriteLog(text);
        },

        GetJsonContent: function (url, SuccessCallBack, ErrorCallBack) {
            GetJsonContent(url, SuccessCallBack, ErrorCallBack);
        },

        PostJsonContent: function (url, content, SuccessCallBack, ErrorCallBack) {
            PostJsonContent(url, content, SuccessCallBack, ErrorCallBack);
        },
    }
}());
